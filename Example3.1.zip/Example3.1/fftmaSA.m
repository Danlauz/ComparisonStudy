function [YSim,errorAll]=fftmaSA(model,c,seed,npU,itt,nbsim,YFCall,nx,dx,ny,dy)
%% Works in 2D 

%%% Input parameters 
% model : parameters for the covariance function (see covardm.m)
% c : sill of each model (see covardm.m) 
% seed : for reproducibility  
% npU : initial number of white noise value that will be replaced
% itt: number of iterations ; scalar
% nbsim : number of simulations ; scalar 
% YFCall : Borehole data for the calibration 
% nx, dx: respectively dimsension and spacing in the direction x 
% ny,dy: grid ; respectively dimsension and spacing in the direction y 
%%% Output parameters 
% YSIM: nbsim calibrated fields ; n x nbsim
% ERR : evolution of the objective function ; nbOpt x nbsim


% WARNING: Simulated field is  (nx+a)*(ny+a) where a is the maximum
% effective range of differents models components.
% Thus, avoid models with large range.

%nbsim simuation
parfor j=1:nbsim
    YFC=YFCall(:,j);    
    p=nan(itt,1);
    error=nan(itt,1);
    np=npU;
    rng('default')
    rng(seed+j)
    %first simulation
    [ysim,~,u,G]=fftma(model,c,seed+j+1234,1,nx,dx,ny,dy);
    %size of the noise matrix in fftma function
    [dim_u1,dim_u2]=size(u);
    
    %Simulated annealing on the MSE by the modification of matrix u
    a=1;
    counter=[0 0 0];
    err0=1000;
    ti=0.01;
    while a<itt
        % modification of np points in the random matrix u
        ui=u;
        %Perturnation of np normal values randomly
        id=randperm(dim_u1*dim_u2,np);
                
        u(id)=randn([length(id),1]);
        %simulation
        U=fftn(u);
        GU=G.*U;
        % Transformation de Fourier inverse donnant g*u et y
        yNew=real(ifftn(GU));
        yNew=yNew(1:nx,1:ny);
        yNew=reshape(yNew,nx*ny,1);

        %Mean-squared error (MSE)
        err1=objFunc(yNew,YFC);
        %Simulated-Annealing
        if err1<=err0
            ysim=yNew;
            err0=err1;
            p(a)=1;
            counter(1)=counter(1)+1;
        else
            if rand(1) < exp((err0-err1)/ti)
                ysim=yNew;
                err0=err1;
                p(a)=exp((err0-err1)/ti);
                counter(2)=counter(2)+1;
            else
                u=ui;
                p(a)=0;
                counter(3)=counter(3)+1;
            end
        end
        %Annealing on ti
        if mod(a,floor(10))==0
            ti=ti/1.2;
        end
        %Annealing on np
        if mod(a,floor(50))==0
            np=ceil(np/1.1);
        end
        error(a)=err0;
        a=a+1;
        if err0<=0
            break;
        end
    end
    % Y to Z
    errorAll(:,j)=error;
    YSim(:,j)=ysim;
end

function [error]=objFunc(ysim,YFC)
ysim=reshape(ysim,[],1);
error=immse(ysim(1:length(YFC)),YFC);