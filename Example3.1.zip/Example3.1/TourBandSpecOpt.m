function [Z,errOpt,phi]=TourBandSpecOpt(x0,model,c,nbOpt,nbsim,YFCall)
%% Note that the program only works with one covariance function. The combination of several covariance functions is not implemented.

%%% Input parameters 
% x0: grid ; n x d where n is the number of points and d the dimension 
% model : parameters for the covariance function (see covardm.m)
% c : sill of each model (see covardm.m)
% nbOpt : number of lines to simulate (nl=nbOpt) ; scalar
% nbsim : number of simulations ; scalar
% YFCall : Borehole data for the calibration   
% nbOpt : number of phases to be optimized ; scalar
%%% Output parameters 
% Z: nbsim calibrated fields ; n x nbsim
% errOpt : evolution of the objective function ; nbOpt x nbsim
% phi : vector of phase ; nbOpt x nbsim



%1- Calculation of f1(s) and F1
[F1,s,rot,cx]=DensSpec1Ddl(x0,model,c);

parfor j=1:nbsim
    %parameters initialization
    YFC=YFCall(:,j);
    ysim=zeros(size(x0,1),1);
    rng('default')
    rng(j+1214);
    Phi=zeros(1,nbOpt);
    errAll=nan(nbOpt,1);
    errBest=1000;
    
    %2-Random number between 0-1 and define ul
    % draw random probabilities
    p=rand(nbOpt,1);
    ul1=interp1(F1{1},s{1},p); % interpolate ul from p and cum
    
    %3-random line generation
    z=VanCorput(nbOpt);    % Van Corput sequence
    %4- scalar product of line z with density line ul
    z1=z.*ul1;
    for i=1:nbOpt   
        %5- Calculation of Z(x); repeat nbOpt time
        options=optimset('MaxIter',5,'TolX',10^-8,'Display','off');
        func = @(Uopt) OptErr(ysim,Uopt,c,cx,rot,z1,i,YFC);
        X=rand();
        X=[X-0.5 X+0.5];
        [Uopt,err] = fminbnd(func,X(1),X(2),options);
        ysim=ysim*sqrt((i-1)/i)+ sqrt(2/i)*sqrt(c(1))*cos((cx{1}(:,[1 2 3])*rot{1}')*z1(i,:)'+ 2*pi*Uopt);
        Phi(i)=mod(Uopt,1);
        
        if err<errBest
            ysimBest=ysim;
            errBest=err;
        end
        errAll(i+nbOpt-nbOpt)=errBest;        
    end    
    Z(:,j)=ysimBest;
    phi(:,j)=Phi;
    errOpt(:,j)=errAll;
end

function [error]=OptErr(ysim,U,c,cx,rot,z1,j,YFC)
ysim=ysim*sqrt((j-1)/j)+ sqrt(2/j)*sqrt(c(1))*cos((cx{1}(:,[1 2 3])*rot{1}')*z1(j,:)'+ 2*pi*mod(U,1));

error=immse(ysim(1:length(YFC)),YFC);
