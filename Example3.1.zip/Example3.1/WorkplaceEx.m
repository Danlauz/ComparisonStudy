
%% Initialization section
model=[ 2 10 10 10 0 0 0]; c=[1]; %variogram model for covardm.m and DensSpec1Ddl.m
nbsim=250; %number of realizations (in the article : 2000)
nx=100; ny=31; nz=1; %dimension of the field (fix nz=1)
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid
niter=5000; % number of iterations
%% References boreholes holds in YHD
Yref=LUsim(x0,model,c,nbsim,[],[],125);
for i=1:nbsim
    aa=anamor(Yref(:,i));
    Yref(:,i)=aa(:,end);
end
YHD=Yref(1:nx,:);

%% Conditional distribution obtained by simple kriging
for j=1:nbsim 
    [YKS(:,j),SigKS(:,j)]=KrigingS(YHD(:,j),x0(1:nx,:),x0,model,c);
end
%% Conditional simulations thru post-conditioning by kriging holds in YPC
k=covardm(x0(1:nx,:),x0(1:nx,:),model,c);
ki=inv(k);
k0=covardm(x0(1:nx,:),x0,model,c);
YUC=LUsim(x0,model,c,nbsim,[],[],3451);
for j=1:nbsim
    aa=postcond([x0(1:nx,:) ,YHD(:,j)],[x0(1:nx,:) , YUC(1:nx,j)],[x0 ,YUC(:,j)],1,ki,k0);
    YPC(:,j)=aa(:,end);
end
%% Gradual deformation (GD)
nbGD=niter/5;
tic
[ZSimGD,errGD]=GDOpt(x0,model,c,nbsim,YHD,nbGD);
tGD=toc/nbsim
%% Iterative spatial resampling (ISR) 
nbISR=niter;
tic
[ZSimISR,errISR]=ISROpt(x0,model,c,nbsim,YHD,nbISR);
tISR=toc/nbsim
%% Sequential spectral turning bands method (S-STBM)
nbOpt=niter/5;
tic
[ZSimSSTBM,errSSTBM]=TourBandSpecOpt(x0,model,c,nbOpt,nbsim,YHD);
tSSTBM=toc/nbsim
%% Phase annealing (PA)
nbPA=niter;
tic
[ZSimPA,errPA]=PhaseAnnealing2D(nx,1,ny,1,model,c,nbsim,YHD,nbPA,200);
tPA=toc/nbsim 
%% Fast Fourier transform moving average simulated annealing (FFTMA-SA)
nbfftmaSA=niter; np=floor(0.4*nx*ny);
tic
[ZSimfftmaSA,errFFTMASA]=fftmaSA(model,c,1245,np,nbfftmaSA,nbsim,YHD,nx,1,ny,1);
tfftmaSA=toc/nbsim

%% Do the figures
Figures
