function [Z,ERROR]=GDOpt(x0,model,c,nbsim,YFCall,nbGrad)
%%% Input parameters 
% x0: grid ; n x d where n is the number of points and d the dimension 
% model : parameters for the covariance function (see covardm.m)
% c : sill of each model (see covardm.m)
% nbsim : number of simulations ; scalar
% YFCall : Borehole data for the calibration   
% nbGrad: number of iterations ; scalar

%%% Output parameters 
% Z: nbsim calibrated fields ; n x nbsim
% ERROR : evolution of the objective function ; nbGrad x nbsim

parfor j=1:nbsim
    YFC=YFCall(:,j);
    rng('default')
    rng(j+54154);
    ysim=LUsim(x0,model,c,1,[],[],13+j*nbGrad);
    ynew=LUsim(x0,model,c,nbGrad,[],[],4585+j*nbGrad);
    
    errNow=1000;
    err=nan(nbGrad,1);
    ii=1;
    for i=1:nbGrad
        %7- Calculation of Z(x); repeat nl time
        options=optimset('MaxIter',5,'TolX',10^-8,'Display','off');
        func = @(t) OptErr(ysim,ynew(:,i),YFC,t);
        X=rand()*2*pi;
        X=[X-pi X+pi];
        [t,errNew] = fminbnd(func, X(1),X(2) ,options);
        if errNew<=errNow
            errNow=errNew;
            ysim=ysim*cos(t)+ynew(:,ii)*sin(t);
        end
        if errNow<=0
            break;
        end
        err(i)=errNow;
        ii=ii+1;
    end
    Z(:,j)=ysim;
    ERROR(:,j)=err;
end

function [error]=OptErr(ysim,ynew,YFC,t)
ysim=ysim*cos(t)+ynew*sin(t);
error=immse(ysim(1:length(YFC)),YFC);

