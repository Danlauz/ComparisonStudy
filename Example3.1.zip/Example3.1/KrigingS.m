function [ZKS,SigKS]=KrigingS(Z,x0,xi,model,c)
%Z: hard data
%x0: Position of the hard data
%xi: Position of estimation point

k=covardm(x0,x0,model,c);
k0=covardm(x0,xi,model,c);
lamda= k\k0;
ZKS=sum(lamda.*Z);
SigKS=sqrt(abs(sum(c)-sum(lamda.*k0)));