function [YSIM,ERR] = PhaseAnnealing2D(nx,dx,ny,dy,model,c,nbsim,YFCall,nbPA,NP)

%%% Input parameters 
% nx, dx: respectively dimsension and spacing in the direction x 
% ny,dy: grid ; respectively dimsension and spacing in the direction y 
% model : parameters for the covariance function (see covardm.m)
% c : sill of each model (see covardm.m)
% nbsim : number of simulations ; scalar
% YFCall : Borehole data for the calibration   
% nbPA: number of iterations ; scalar
% NP : initial number of phases to be exchanged
%%% Output parameters 
% YSIM: nbsim calibrated fields ; n x nbsim
% ERR : evolution of the objective function ; nbOpt x nbsim
% phi : vector of phase ; nbOpt x nbsim

parfor j=1:nbsim
    YFC=YFCall(:,j);
    np=NP;npall=NP;
    err=nan(nbPA,1);
    xdim=length(1:dx:nx);ydim=length(1:dy:ny);
    nxsim=2*nx; nysim=2*ny;

    % note : the one remains for the starting value for the objective
    %%% PA paramaters
    Tfac            = 1/1.05;  % T[t] = Tstart*Tfac**t
    obj_min         = 0;      % minimum objective to stop annealing
    nphase          = [49 14];     % nphase*2 = number of phases used
    NN              = 10;      % number of steps for each temperature
    Tstart          = 0.001;      % starting temperature
    
    
    rng('default')
    rng(j+48754);
    % Starting random field
    inputfield=fftma(model,c,14515+j,1,nxsim,1,nysim,1);
    inputfield=reshape(inputfield,[nxsim nysim]);
    
    % calculate spectrum
    spec = reshape(fftshift(fftn(inputfield)),[],1);
    % amplitude spectra
    Amp = abs(spec); 
    
    % initialize things
    objective       = 100;          % this is the current objective at each step
    objective_best  = 100;          % objective_best is always the best objective
    tt = 0 ;
    nn = 0 ;
    doannealing = true;
    counter = [0,0,0];
    counterEND = [0,0,0];
    
    sim_best=inputfield;
    
    while  doannealing == true 
        TT = Tstart*Tfac^tt;

        % draw a random vector and a random phase
        rn=[randi([ceil(nxsim/2)-nphase(1), ceil(nxsim/2)+nphase(1)],np,1) randi([ceil(nysim/2)-nphase(2), ceil(nysim/2)+nphase(2)],np,1)];
        rnw= unique(rn(:,2)*nxsim+rn(:,1)+1,'stable');
        rnwconj= unique((nysim-rn(:,2))*nxsim+(nxsim-rn(:,1))+1,'stable');
        om_new=rand(length(rnw),1)*2*pi;
        % change phase angle and update the values
        spec_up = Amp(rnw).*exp(1j*om_new);
        spec_up_m = Amp(rnwconj).*exp(1j*(-1)*om_new);
        
        
        specNew=spec;
        specNew(rnw) = spec_up ;
        specNew(rnwconj) = spec_up_m ;
        simNew=real(ifftn(ifftshift(reshape(specNew,[nxsim,nysim]))));
        %%% Annealing
        objective_new=objFunc(simNew,YFC,xdim,ydim,nxsim,nysim);
        if (objective_new <= objective)
            % leave it and go on
            objective = objective_new ;
            spec(rnw) = spec_up ;
            spec(rnwconj) = spec_up_m ;
            sim = simNew ;
            counter(1) = counter(1)+1 ;
            % check best objective
            if objective < objective_best
                objective_best = objective;
                sim_best=sim;
            end    
        else
            % calculate probability
            prob = exp(-(objective_new - objective)/TT);
            if rand(1)-prob <= 0
                % leave it and go on
                objective = objective_new ;
                spec(rnw) = spec_up ;
                spec(rnwconj) = spec_up_m ;
                counter(2) = counter(2)+1;
                
            else
                % keep old spec and old sim_uc1, sim_uc2
                counter(3) = counter(3)+1;
            end
        end
        
        if nn == NN
            nn = 0;      % set number in timestep to zero
            tt =tt+1;     % set timestep to next one
            npall=npall/1.02;
            np=ceil(npall);
            % check stopping criteria
            % -----------------------
            if (objective_best <= obj_min)
                doannealing = false;
                counterEND(3)=counterEND(3)+1;
                %warning( 'defined minimum objective reached')
            end
            % stop after 15000 iterations
            % that is rather arbitrary at the moment
            if sum(counter) >= nbPA
                doannealing = false;
            end
        end
        nn=nn+1;
        err(sum(counter))=objective_best;
        if objective_best<=0
            break;
        end
    end

    ysim=reshape(sim_best,[nxsim nysim]);
    ysim = ysim(ceil(xdim/2):ceil(xdim/2)+xdim-1,ceil(ydim/2):ceil(ydim/2)+ydim-1);
    ysim=reshape(ysim,[],1);
    
    ERR(:,j)=err;
    YSIM(:,j)=ysim;
end

function [error]=objFunc(ysim,YFC,xdim,ydim,nxsim,nysim)

ysim=reshape(ysim,[nxsim nysim]);
ysim = ysim(ceil(xdim/2):ceil(xdim/2)+xdim-1,ceil(ydim/2):ceil(ydim/2)+ydim-1);
ysim=reshape(ysim,[],1);

error=immse(ysim(1:length(YFC)),YFC);