nbsim=200;
%VarSimAR=varioFFT2D_dl( x0 , ZSimAR(:,1:end) , 1 , 0 , 0 );
VarSimC=varioFFT2D_dl( x0 , ZSimC(:,1:nbsim) , 1 , 0 , 0 );
VarSimCAD=varioFFT2D_dl( x0 , YPC(:,1:nbsim) , 1 , 0 , 0 );
VarSimPA=varioFFT2D_dl( x0 , ZSimPA(:,1:nbsim) , 1 , 0 , 0 );
VarSimGD=varioFFT2D_dl( x0 , ZSimGD(:,1:nbsim) , 1 , 0 , 0 );
VarSimISR=varioFFT2D_dl( x0 , ZSimISR(:,1:nbsim) , 1 , 0 , 0 );
VarSimCSWAP=varioFFT2D_dl( x0 , ZSimCSWAP(:,1:nbsim) , 1 , 0 , 0 );
VarSimfftmaSA=varioFFT2D_dl( x0 , ZSimfftmaSA(:,1:nbsim) , 1 , 0 , 0 );


VarRefx{1}=c-covardm(x0,[1 1 1],model,c);

jj=0;

jj=jj+1;
figure(jj)

%meanvarSimAR=zeros(length(VarSimAR{1,1}(nx:end,ny)),1);
meanvarSimC=zeros(length(VarSimC{1,1}(nx:end,ny)),1);
meanvarSimCAD=zeros(length(VarSimCAD{1,1}(nx:end,ny)),1);
meanvarSimGD=zeros(length(VarSimGD{1,1}(nx:end,ny)),1);
meanvarSimPA=zeros(length(VarSimPA{1,1}(nx:end,ny)),1);
meanvarSimISR=zeros(length(VarSimISR{1,1}(nx:end,ny)),1);
meanvarSimCSWAP=zeros(length(VarSimCSWAP{1,1}(nx:end,ny)),1);
meanvarSimfftmaSA=zeros(length(VarSimfftmaSA{1,1}(nx:end,ny)),1);
for i=1:nbsim
   % meanvarSimAR=meanvarSimAR+VarSimAR{i,i}(nx:end,ny)/nbsim;
    meanvarSimC=meanvarSimC+VarSimC{i,i}(nx:end,ny)/nbsim;
    meanvarSimCAD=meanvarSimCAD+VarSimCAD{i,i}(nx:end,ny)/nbsim;
    meanvarSimPA=meanvarSimPA+VarSimPA{i,i}(nx:end,ny)/nbsim;
    meanvarSimGD=meanvarSimGD+VarSimGD{i,i}(nx:end,ny)/nbsim;
    meanvarSimISR=meanvarSimISR+VarSimISR{i,i}(nx:end,ny)/nbsim;
    meanvarSimCSWAP=meanvarSimCSWAP+VarSimCSWAP{i,i}(nx:end,ny)/nbsim;
    meanvarSimfftmaSA=meanvarSimfftmaSA+VarSimfftmaSA{i,i}(nx:end,ny)/nbsim;
end
%plot(meanvarSimAR,'-r','LineWidth',1);
%hold on
plot(meanvarSimC,'-b','LineWidth',1);
hold on
plot(meanvarSimCAD,'-g','LineWidth',1);
hold on
plot(meanvarSimGD,'--r','LineWidth',1);
hold on
plot(meanvarSimPA,'--b','LineWidth',1);
hold on
plot(meanvarSimISR,'--g','LineWidth',1);
hold on
plot(meanvarSimCSWAP,'-.r','LineWidth',1);
hold on
plot(meanvarSimfftmaSA,'-.b','LineWidth',1);
hold on
plot(VarRefx{1},'-k','LineWidth',2)
hold on
legend('S-STBM','S-STBM-AD','GD','PA','ISR','S-STBM-SWAP','FFTMA-SA')
xlim([0 75])

%%
figure(jj+1)

%meanvarSimAR=zeros(length(VarSimAR{1,1}(nx,ny:end)),1);
meanvarSimC=zeros(length(VarSimC{1,1}(nx,ny:end)),1);
%meanvarSimCAD=zeros(length(VarSimCAD{1,1}(nx,ny:end)),1);
meanvarSimGD=zeros(length(VarSimGD{1,1}(nx,ny:end)),1);
meanvarSimPA=zeros(length(VarSimPA{1,1}(nx,ny:end)),1);
meanvarSimISR=zeros(length(VarSimISR{1,1}(nx,ny:end)),1);
meanvarSimCSWAP=zeros(length(VarSimCSWAP{1,1}(nx,ny:end)),1);
meanvarSimfftmaSA=zeros(length(VarSimfftmaSA{1,1}(nx,ny:end)),1);
for i=1:nbsim
   % meanvarSimAR=meanvarSimAR+VarSimAR{i,i}(nx,ny:end)'/nbsim;
    meanvarSimC=meanvarSimC+VarSimC{i,i}(nx,ny:end)'/nbsim;
    %meanvarSimCAD=meanvarSimCAD+VarSimCAD{i,i}(nx,ny:end)'/nbsim;
    meanvarSimPA=meanvarSimPA+VarSimPA{i,i}(nx,ny:end)'/nbsim;
    meanvarSimGD=meanvarSimGD+VarSimGD{i,i}(nx,ny:end)'/nbsim;
    meanvarSimISR=meanvarSimISR+VarSimISR{i,i}(nx,ny:end)'/nbsim;
    meanvarSimCSWAP=meanvarSimCSWAP+VarSimCSWAP{i,i}(nx,ny:end)'/nbsim;
    meanvarSimfftmaSA=meanvarSimfftmaSA+VarSimfftmaSA{i,i}(nx,ny:end)'/nbsim;
end
%plot(meanvarSimAR,'-r','LineWidth',1);
%hold on
plot(meanvarSimC,'-b','LineWidth',1);
hold on
%plot(meanvarSimCAD,'-g','LineWidth',1);
%hold on
plot(meanvarSimGD,'--r','LineWidth',1);
hold on
plot(meanvarSimPA,'--b','LineWidth',1);
hold on
plot(meanvarSimISR,'--g','LineWidth',1);
hold on
plot(meanvarSimCSWAP,'-.r','LineWidth',1);
hold on
plot(meanvarSimfftmaSA,'-.b','LineWidth',1);
hold on
plot(VarRefx{1},'-k','LineWidth',2)
hold on
legend('S-STBM','GD','PA','ISR','S-STBM-SWAP','FFTMA-SA')
xlim([0 75])