function [Z,errISR]=ISROpt(x0,model,c,nbsim,YFCall,nbISR)
%%% Input parameters 
% x0: grid ; n x d where n is the number of points and d the dimension 
% model : parameters for the covariance function (see covardm.m)
% c : sill of each model (see covardm.m)
% nbsim : number of simulations ; scalar
% YFCall : Borehole data for the calibration   
% nbISR: number of iterations ; scalar

%%% Output parameters 
% Z: nbsim calibrated fields ; n x nbsim
% errISR : evolution of the objective function ; nbISR x nbsim


%matrix of covariance of observed data for the post-conditioning
k=covardm(x0(:,1:3),x0(:,1:3),model,c);
k0=covardm(x0(:,1:3),x0,model,c);

parfor j=1:nbsim
    YFC=YFCall(:,j);
    rng('default')
    rng(j+6525);
    ysim=LUsim(x0,model,c,1,[],[],12536+j*nbISR);
    ynew=LUsim(x0,model,c,nbISR,[],[],9523+j*nbISR);
    ii=0;
    errNow=1000;
    err=nan(nbISR,1);
    for i=1:nbISR
        
        idx=randperm(length(x0),floor(0.01*length(x0)));
        PosISR=unique(idx);
        
        kNow=k(PosISR,PosISR);
        ki=inv(kNow);
        k0Now=k0(PosISR,:);
        
        ysim_star= postcond( [x0(PosISR,:) ,ysim(PosISR)] , [x0(PosISR,:) , ynew(PosISR,i)], [x0 ,ynew(:,i)] , 1 , ki ,k0Now );
        ysim_star=ysim_star(:,end);
        
        errNew=immse(ysim_star(1:length(YFC)),YFC);
        if errNew<=errNow
            errNow=errNew;
            ysim=ysim_star;
            ii=ii+1;
        end
        
        if errNow<=0
            break;
        end
        err(i)=errNow;
    end
    Z(:,j)=ysim;
    errISR(:,j)=err;
end

