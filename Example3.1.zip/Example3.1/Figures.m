%% One example of conditional distribution
figure(1)
imagesc(reshape(Yref(:,2),[nx ny]))
set(gca,'YDir','normal');colormap('jet');caxis([-3 3]);colorbar();
hold on
plot(x0(1:100,2),x0(1:100,1),'-k','LineWidth',2)
hold on 
plot(x0(1340,2),x0(1340,1),'ok','LineWidth',2)
for i=[1:20:100 100]
    hold on 
plot(x0([i,1340],2),x0([i,1340],1),'-k','LineWidth',0.5)
end
hold on
text(x0(1345,2),x0(1345,1),'Z_n ~ N(\mu_S_K,\sigma^2_S_K)','Color','black','FontSize',16,'FontWeight','bold')

%% Compute Y_(n,j)=(Z_(n,j)-mu_KS)/sigma_KS ~ N(0,1)
YSimSSTBM=(ZSimSSTBM-YKS)./SigKS;
YSimGD=(ZSimGD-YKS)./SigKS;
YSimISR=(ZSimISR-YKS)./SigKS;
YSimPA=(ZSimPA-YKS)./SigKS;
YSimfftmaSA=(ZSimfftmaSA-YKS)./SigKS;
YSimUC=(YUC-YKS)./SigKS;
YSimPC=(YPC-YKS)./SigKS;

%% Anderson-Darling and Kolmogorov-Smirnov test

dist = makedist('normal','mu',0,'sigma',1);
for i=nx+1:length(Yref)
    ii=i-nx;
    dist = makedist('normal','mu',0,'sigma',1);
    [hC(ii),pC(ii)] = adtest(YSimSSTBM(i,:),'Distribution',dist);
    [hGD(ii),pGD(ii)] = adtest(YSimGD(i,:),'Distribution',dist);
    [hISR(ii),pISR(ii)] = adtest(YSimISR(i,:),'Distribution',dist);
    [hPA(ii),pPA(ii)] = adtest(YSimPA(i,:),'Distribution',dist);
    [hfftmaSA(ii),pfftmaSA(ii)] = adtest(YSimfftmaSA(i,:),'Distribution',dist);
end
ADStat=[sum(hC),sum(hGD),sum(hISR),sum(hPA),sum(hfftmaSA)]/3000*100;

for i=nx+1:length(Yref)
    ii=i-nx;
    [hKSC(ii),pKSC(ii)] = kstest(YSimSSTBM(i,:));
    [hKSGD(ii),pKSGD(ii)] = kstest(YSimGD(i,:));
    [hKSISR(ii),pKSISR(ii)] = kstest(YSimISR(i,:));
    [hKSPA(ii),pKSPA(ii)] = kstest(YSimPA(i,:));
    [hKSfftmaSA(ii),pKSfftmaSA(ii)] = kstest(YSimfftmaSA(i,:));
end
KSStat=[sum(hKSC),sum(hKSGD),sum(hKSISR),sum(hKSPA),sum(hKSfftmaSA)]/3000*100;

%% Average objective function 
figure(2)
plot(1:5:niter,mean(errSSTBM,2),'k','Linewidth',2)
hold on
plot(1:5:niter,mean(errGD,2),'b','Linewidth',2)
hold on
plot(mean(errISR,2),'r','Linewidth',2)
hold on
plot(mean(errPA,2),'g','Linewidth',2)
hold on
plot(mean(errFFTMASA,2),'m','Linewidth',2)
xlim([0 niter])
ylim([2*10^-2 2])
xlabel('number of iterations')
ylabel('Objective function')
set(gca, 'YScale', 'log')
legend('S-STBM','GD','ISR','PA','FFTMA-SA')
%% Table 1
Methods = {'AD';'KS';'mean OF';'std OF'};
SSTBM = [ADStat(1); KSStat(1) ;mean(errSSTBM(end,:)); std(errSSTBM(end,:))];
GD = [ADStat(2); KSStat(2); mean(errGD(end,:)); std(errGD(end,:))];
ISR = [ADStat(3); KSStat(3); mean(errISR(end,:)) ;std(errISR(end,:))];
PA = [ADStat(4); KSStat(4); mean(errPA(end,:)); std(errPA(end,:))];
FFTMASA = [ADStat(5); KSStat(5); mean(errFFTMASA(end-1,:)); std(errFFTMASA(end-1,:))];
T = table(Methods,SSTBM,GD,ISR,PA,FFTMASA)
%% Compute mean, std, skewness and kurtosis of distributions Y

meanC = mean(YSimSSTBM(nx+1:end,:)');
meanGD = mean(YSimGD(nx+1:end,:)');
meanISR = mean(YSimISR(nx+1:end,:)');
meanPA = mean(YSimPA(nx+1:end,:)');
meanfftmaSA = mean(YSimfftmaSA(nx+1:end,:)');
meanUC = mean(YSimUC(nx+1:end,:)');
meanPC = mean(YSimPC(nx+1:end,:)');

varC = std(YSimSSTBM(nx+1:end,:)');
varGD = std(YSimGD(nx+1:end,:)');
varISR = std(YSimISR(nx+1:end,:)');
varPA = std(YSimPA(nx+1:end,:)');
varfftmaSA = std(YSimfftmaSA(nx+1:end,:)');
varUC = std(YSimUC(nx+1:end,:)');
varPC = std(YSimPC(nx+1:end,:)');


skewnessC = skewness(YSimSSTBM(nx+1:end,:)');
skewnessGD = skewness(YSimGD(nx+1:end,:)');
skewnessISR = skewness(YSimISR(nx+1:end,:)');
skewnessPA = skewness(YSimPA(nx+1:end,:)');
skewnessfftmaSA = skewness(YSimfftmaSA(nx+1:end,:)');
skewnessUC = skewness(YSimUC(nx+1:end,:)');
skewnessPC = skewness(YSimPC(nx+1:end,:)');

kurtosisC = kurtosis(YSimSSTBM(nx+1:end,:)');
kurtosisGD = kurtosis(YSimGD(nx+1:end,:)');
kurtosisISR = kurtosis(YSimISR(nx+1:end,:)');
kurtosisPA = kurtosis(YSimPA(nx+1:end,:)');
kurtosisfftmaSA = kurtosis(YSimfftmaSA(nx+1:end,:)');
kurtosisUC = kurtosis(YSimUC(nx+1:end,:)');
kurtosisPC = kurtosis(YSimPC(nx+1:end,:)');

%%
figure(5)
boxplot([kurtosisC ;kurtosisGD ;kurtosisISR; kurtosisPA; kurtosisfftmaSA; kurtosisUC; kurtosisPC]','Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC','PC'},'Whisker',1)
hold on 
plot([-9 9],[3 3],'--k','linewidth',1.5)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
ylabel('Kurtosis')
figure(6)
boxplot([skewnessC ;skewnessGD ;skewnessISR; skewnessPA; skewnessfftmaSA; skewnessUC; skewnessPC]','Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC','PC'},'Whisker',1)
hold on 
plot([-9 9],[0 0],'--k','linewidth',1.5)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
ylabel('Skewness')
figure(7)
boxplot([varC ;varGD ;varISR; varPA; varfftmaSA; varUC; varPC]','Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC','PC'},'Whisker',1)
hold on 
plot([-9 9],[1 1],'--k','linewidth',1.5)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
ylim([0.8 2])
ylabel('Standard deviation')
figure(8)
boxplot([meanC ;meanGD ;meanISR; meanPA; meanfftmaSA; meanUC; meanPC]','Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC','PC'},'Whisker',1)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
hold on 
plot([-9 9],[0 0],'--k','linewidth',1.5)
ylabel('Mean')