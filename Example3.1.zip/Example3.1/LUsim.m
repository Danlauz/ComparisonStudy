function ysim=LUsim(x0,model,c,nbsim,Yref,Pos,seed)

rng('default')
rng(seed);
K=covardm(x0(:,1:end),x0(:,1:end),model,c);
L=chol(K)';
Y=randn(size(x0,1),nbsim);

ysim=L*Y;


if ~isempty(Pos) 
    k=covardm(x0(Pos,1:end),x0(Pos,1:end),model,c);
    ki=inv(k);
    k0=covardm(x0(Pos,1:end),x0,model,c);
    ysim= postcond( [x0(Pos,:) ,Yref] , [x0(Pos,:) , ysim(Pos,:)], [x0 ,ysim] , nbsim , ki ,k0 );
    ysim=ysim(:,4:end);
end



