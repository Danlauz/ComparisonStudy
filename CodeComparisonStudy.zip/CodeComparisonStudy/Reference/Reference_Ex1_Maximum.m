%clear all
%% Initialization section
model=[2 5 5 5 0 0 0]; c=[1]; %variogram model from varioFFT2D_dl.m and covardm.m
nl=2000; %number of lines to simulate
nbsim=2000; %number of realization performed
nx=21; ny=20; nz=1; %dimension of the field (fix nz=1)
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid
Pos=1:nx*ny*nz;
deltay=2;
deltax=2;
LocData1=Pos(x0(:,1)>=(11-deltax) & x0(:,1)<=(11+deltax) & x0(:,2)>=(3-deltay) & x0(:,2)<=(3+deltay));
LocData2=Pos(x0(:,1)>=(11-deltax) & x0(:,1)<=(11+deltax) & x0(:,2)>=(8-deltay) & x0(:,2)<=(8+deltay));
LocData3=Pos(x0(:,1)>=(11-deltax) & x0(:,1)<=(11+deltax) & x0(:,2)>=(13-deltay) & x0(:,2)<=(13+deltay));
LocData4=Pos(x0(:,1)>=(11-deltax) & x0(:,1)<=(11+deltax) & x0(:,2)>=(18-deltay) & x0(:,2)<=(18+deltay));


LocData{1}=LocData1 ;
LocData{2}=LocData2 ;
LocData{3}=LocData3 ;
LocData{4}=LocData4 ;

LocHD=[];
zHD=[];

maxRef=[0.4 0.82 1.37 1.64];
ConstantData{1}=maxRef;
ConstantData{2}=LocData;

clearvars -except LocHD zHD ConstantData x0 LocData
save('Data/Ex1_Data.mat')