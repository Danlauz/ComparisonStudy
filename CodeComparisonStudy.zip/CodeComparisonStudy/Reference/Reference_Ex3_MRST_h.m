model=[ 4 40 20 20 0 0 0]; c=[1]; %covariance model
nbsim=1; %One reference field
nx=101; ny=101; nz=1; %dimension of the field (fix nz=1)
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid

%Piezometer location
x0Ref=[ 12 12 ;12 91 ; 91 12 ; 91 91 ; 51 51 ;...
        57 51 ;65 51 ;75 51 ; ...
        45 51 ;37 51 ;27 51 ; ...
        51 57 ;51 65 ;51 75 ; ...
        51 45 ;51 37 ;51 27 ];
%Index in grid
LocData=nx*(x0Ref(:,2)-1)+x0Ref(:,1);
%Source Localisation and Index
x0Ref=[ 51 51];
LocInj=nx*(x0Ref(:,2)-1)+x0Ref(:,1);
%%

%Gaussien field reference
zrefGaus= FFTMA(model,c,125125,1,nx,1,ny,1,nz,1); 
zref=zrefGaus-10;

%gravity reset off

G = cartGrid([nx,ny],[100,100]);
G = computeGeometry(G);
rock = makeRock(G, 100*darcy, 0.3);
rock.perm=10.^zref;

fluid      = initSingleFluid('mu' ,    1*centi*poise, ...
                             'rho', 1000*kilogram/meter^3);
Q=-0.002;
src = addSource([], LocInj, Q , 'sat', 1);

bc  = pside([], G, 'EAST', 0 , 'sat', 1);
bc  = pside(bc, G, 'WEST', 9.80638*1000, 'sat', 1);

T   = computeTrans(G, rock);
InitSol=initResSol(G, 0.0,1);

sol = incompTPFA(initResSol(G, 0.0,1), G, T, fluid, 'bc', bc,'src',src);


P=sol.pressure;
x = linspace(1,nx,ny);
y = linspace(1,nx,ny);
[X,Y] = meshgrid(x,y);
Z = reshape(P*0.000101974,[nx,ny])';
figure(1)
imagesc(reshape(P*0.000101974,[nx,ny])');
hold on 
plot(x0(LocInj,1),x0(LocInj,2),'ok','markersize',8,'LineWidth',2)
hold on 
plot(x0(LocData,1),x0(LocData,2),'xk','markersize',8,'LineWidth',2)
hold on
[c1,h]=contour(X,Y,Z,[0.80,0.80,0.60,0.60,0.40,0.40,0.20,0.20,0.10,0.10,0.00,0.00],'--k','ShowText','on');
h.LevelList=round(h.LevelList,2); 
clabel(c1,h)
colormap(jet)
colorbar()
caxis([-1 1])
set(gca,'YDir','normal')
title('Reference pressure head field (m)')

figure(2)
imagesc(reshape(zrefGaus-3,[nx,ny])');
hold on 
plot(x0(LocInj,1),x0(LocInj,2),'ok','markersize',8,'LineWidth',2)
hold on 
plot(x0(LocData,1),x0(LocData,2),'xk','markersize',8,'LineWidth',2)
clabel(c1,h)
colormap(jet)
colorbar()
title('Reference log_1_0K field (m/s)')
set(gca,'YDir','normal')
%%
LocHD=[];
zHD=[];

hData=sol.pressure(LocData)*0.000101974;
hField=sol.pressure*0.000101974;

ConstantData{1}=G;
ConstantData{2}=fluid;
ConstantData{3}=src;
ConstantData{4}=bc;
ConstantData{5}=rock;
ConstantData{6}=InitSol;
ConstantData{7}=LocData;
ConstantData{8}=hData;

clearvars -except LocHD zHD zrefGaus hField ConstantData LocData LocInj x0
save('Data/Ex3_Data.mat')
