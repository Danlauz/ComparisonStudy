load('Data/AssRef.mat')
zrefGaus=Zref; clear Zref

Ufield=(tiedrank(zrefGaus) - 0.5) / (100*100);

figure(1)
imagesc(reshape(Ufield,[100,100]));
set(gca,'YDir','normal')
colormap(jet)
colorbar()
title('Rank field')

figure(2)
imagesc(reshape(zrefGaus,[100,100]));
set(gca,'YDir','normal')
colormap(jet)
colorbar()
title('Z field')

zHD=[];
LocHD=[];

x0=grille3(1,100,1,1,100,1,1,1,1);

ConstantData{1}=x0;
ConstantData{2}=AssRef;

clearvars -except zrefGaus LocHD zHD UField ConstantData
save('Data/Ex5_Data.mat')
