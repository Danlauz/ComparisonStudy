model=[6 15 25 15 0 0 30]; c=[1]; %Covariance model
nbsim=1; %One reference
nx=101; ny=101; nz=1; %dimension of the field (fix nz=1)
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid

%Producer localisation
x0Ref=[ 11 11; 91 11 ; 11 91 ; 91 91];
LocProd=nx*(x0Ref(:,2)-1)+x0Ref(:,1);

%Injector localisation
x0Ref=[51 51];
LocInj=nx*(x0Ref(:,2)-1)+x0Ref(:,1);
%%
zrefGaus=FFTMA(model,c,17565,1,nx,1,ny,1,nz,1);
%% Initialization

G = cartGrid([nx,ny],[100 100]);
G = computeGeometry(G);

gravity reset off
fluid      = initSingleFluid('mu' ,    1*centi*poise, ...
                             'rho', 1014*kilogram/meter^3);
Q= 0.004;
src = addSource([],  LocInj(1),    Q, 'sat', 1);
src = addSource(src, LocProd(1),  -Q/4, 'sat', 1);
src = addSource(src, LocProd(2),  -Q/4, 'sat', 1);
src = addSource(src, LocProd(3),  -Q/4, 'sat', 1);
src = addSource(src, LocProd(4),  -Q/4, 'sat', 1);

bc  = pside([], G, 'EAST', 0 , 'sat', 1);
bc  = pside(bc, G, 'WEST', 9.80638*1000, 'sat', 1);
bc  = fluxside(bc, G, 'South', 0, 'sat', 1);
bc  = fluxside(bc, G, 'North', 0, 'sat', 1);

rock = makeRock(G, 100*milli*darcy, 0.2);

InitSol=initResSol(G, 0, 1);

zporo=zeros(size(zrefGaus));
zporo(zrefGaus<0)=0.30;
zporo(zrefGaus>=0)=0.30; 
zperm=zeros(size(zrefGaus));
zperm(zrefGaus<0)=125*darcy; %10^-3 clean sand
zperm(zrefGaus>=0)=0.8*darcy; %10^-5 silty sand
rock.poro=zporo;
rock.perm=zperm;


%% Solve pressure equation
% Compute transmissibilities and solve pressure equation
trans  = simpleComputeTrans(G, rock);
xr = simpleIncompTPFA(InitSol, G, trans, fluid, 'src', src,'bc',bc);

%% Compute time-of-flight
% Once the fluxes are given, the time-of-flight equation is discretized
% with a standard upwind finite-volume method
Ta = computeTimeOfFlight(xr, G, rock, 'src',src,'bc',bc);
tData=Ta(LocProd)/60/60/24;

%%
P=xr.pressure;
x = linspace(1,nx,ny);
y = linspace(1,nx,ny);
[X,Y] = meshgrid(x,y);
Z = reshape(P*0.000101974,[nx,ny])';

figure(7); imagesc(reshape(zperm,[nx ny]));set(gca,'YDir','normal'); colormap([1 1 1 ; 0.6 0.6 0.6]); colorbar
hold on
plot(x0(5101,2),x0(5101,1),'ok','MarkerSize',8,'LineWidth',2)
hold on 
plot(x0(LocProd,2),x0(LocProd,1),'xk','MarkerSize',8,'LineWidth',2)
hold on 
text(x0(LocProd(1),2),x0(LocProd(1),1)+5.5,'P1','Color','black','FontSize',16,'FontWeight','bold')
hold on 
text(x0(LocProd(2),2)-5,x0(LocProd(2),1)+5,'P2','Color','black','FontSize',16,'FontWeight','bold')
hold on 
text(x0(LocProd(3),2)-7,x0(LocProd(3),1)-3,'P3','Color','black','FontSize',16,'FontWeight','bold')
hold on 
text(x0(LocProd(4),2)+1,x0(LocProd(4),1)-3,'P4','Color','black','FontSize',16,'FontWeight','bold')
hold on 
text(x0(LocInj(1),2)+3,x0(LocInj(1),1)+2,'I','Color','black','FontSize',20,'FontWeight','bold')
title('K field')
%%
mrstModule add streamlines;
seed = [(nx:3*(nx-1):nx*ny).'; (1:3*(nx+1):nx*ny).'; (51:3*101:nx*ny).'; (50*101+1:3*1:51*101).'];
Sf = pollock(G, xr,seed);
Sb = pollock(G, xr,seed,'reverse', true);

figure(3)
imagesc(reshape(zperm/darcy,[nx ny])'); set(gca,'YDir','normal');
hf=streamline(Sf);
hb=streamline(Sb);
set([hf; hb],'Color',[0.5 0.5 0.5]);
hold on 
plot(x0(LocInj,2),x0(LocInj,1),'ok','MarkerSize',8,'LineWidth',2)
hold on 
plot(x0(LocProd,2),x0(LocProd,1),'xk','MarkerSize',8,'LineWidth',2)
title('Streamline and K field')
%%
LocHD=[];
zHD=[];

ConstantData{1}=G;
ConstantData{2}=fluid;
ConstantData{3}=src;
ConstantData{4}=bc;
ConstantData{5}=rock;
ConstantData{6}=InitSol;
ConstantData{7}=LocProd;
ConstantData{8}=tData;

hField=xr.pressure*0.000101974;
clearvars -except zrefGaus LocHD zHD hField ConstantData LocProd LocInj x0 zperm
save('Data/Ex4_Data.mat')
