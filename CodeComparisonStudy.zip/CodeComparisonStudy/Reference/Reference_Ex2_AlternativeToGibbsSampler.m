%clear all
%% Initialization section
model=[ 3 6 6 6 0 0 0]; c=[1]; %variogram model from varioFFT2D_dl.m and covardm.m
nl=5000; %number of lines to simulate
nbsim=2000; %number of realization performed
nx=50; ny=31; nz=1; %dimension of the field (fix nz=1)
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid
%%
LocData=[501:550 1001:1050];
zrefGaus=STBM(x0,model,c,nbsim,[],[],2000,12451);
varRef=zeros(nbsim,1);
lb=zeros(length(LocData),nbsim);
ub=zeros(length(LocData),nbsim);
for i=1:nbsim
    varRef(i)=var(zrefGaus(:,i));
    NewDepth=nan(2,length(LocData));
    NewDepth(1,zrefGaus(LocData,i)>0)=inf;
    NewDepth(2,zrefGaus(LocData,i)>0)=0;
    NewDepth(1,zrefGaus(LocData,i)<=0)=0;
    NewDepth(2,zrefGaus(LocData,i)<=0)=-inf;
    lb(:,i)=NewDepth(1,:)';
    ub(:,i)=NewDepth(2,:)';
end
figure(1)
imagesc(reshape(zrefGaus(:,1),[nx ny]))
hold on
plot(x0(LocData,2),x0(LocData,1),'|k')

%%
sim=6;
zrefInd=nan(length(zrefGaus(:,sim)),1);
zrefInd(zrefGaus(:,sim)<=quantile(zrefGaus(:,sim),0.5))=2;
zrefInd(zrefGaus(:,sim)>quantile(zrefGaus(:,sim),0.5))=1;

figure(3)
imagesc(reshape(zrefInd,[nx ny]))
hold on
plot([11 11],[0 51],'-k','Linewidth',1.5)
hold on
plot([21 21],[0 51],'-k','Linewidth',1.5)
hold on
plot(x0(LocData([25 75]),2),x0(LocData([25 75]),1),'ok','Linewidth',2)
hold on
plot(x0(775,2),x0(775,1),'*k','Linewidth',1.2)
text(x0(LocData([25]),2)-2,x0(LocData([25]),1)+2.5,'x_1^j','FontSize',16, 'FontWeight', 'Bold','Color','black')
text(x0(LocData([75]),2)-2,x0(LocData([75]),1)+2.5,'x_2^j','FontSize',16, 'FontWeight', 'Bold','Color','black')
text(x0(775,2)-2,x0(775,1)+2.5,'x_n^j','FontSize',16, 'FontWeight', 'Bold','Color','black')
set(gca,'YDir','normal')
colormap([1 1 1 ; 0.6 0.6 0.6])
%%
LocHD=[];
zHD=[];

ConstantData{1}=lb;
ConstantData{2}=ub;
ConstantData{3}=varRef;
ConstantData{4}=LocData;

clearvars -except LocHD zHD ConstantData x0 LocData zrefGaus
save('Data/Ex2_Data.mat')