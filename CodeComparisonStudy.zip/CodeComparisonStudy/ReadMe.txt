Simply run the script 'WorkplaceSim.m'. The directives are mentioned in the script.
The variable named type holds the number of the case under study.



Folder Description

1- The folder named 'Data' contains the reference data for the simulation. The data are saved in a .mat file named ExX_Data.mat 
where X is the number of the case. The .mat file contains all the information need to reproduce the case shown in the manuscript.

2- The folder named 'Figures' contains five Matlab functions to generate the figures presented in the manuscript. The manuscript
 figures are given in folder Figures/Ex1, Figures/Ex2, Figures/Ex3, Figures/Ex4, Figures/Ex5, and Figures/ParamAnalysis. Only need
 to run the function code for the case study to show the figure. Some figures may take time to be generated especially ones 
 for statistical analysis (case 1 and case 2). 

3- The folder named 'Function' contains Matlab functions for calibration purpose

   CODE OF THE VARIOGRAM-BASED INVERSION METHODS
   SSTBM.m   : Sequential spectral turning band method
   FFTMASA.m : Fast Fourier Transform Moving Average Simulated Annealing
   ISR.m     : Iterative spatial resampling
   PA.m      : Phase annealing (Only works in 2D) 
   GD.m      : Gradual deformation

    
    ObjectiveFunction.m : Contains the objective function for the five cases.
    ParamSimulation.m   : COntains parameters for the simulation (e.g. covariance model, size grid, ...)

    The other functions are needed to run the five variogram-based inversion methods listed above
       
    FFTMA.m         : Fast Fourier Transform Moving Average, generated uncalibrated simulations
    STBM.m          : Spectral turning band method, generated uncalibrated simulations
    LUsim.m         : Cholesky decomposition simulation, generated uncalibrated simulations
    covardm.m       : Computes the covariance matrix
    DensSpecDdl.m   : Computes the one-dimensional spectral density from the desired covariance matrix
    grille2.m       : Generated the regular 2D grid
    grille3.m       : Generated the regular 3D grid
    postcond.m      : Performs post-conditionning by kriging
    VanCorput.m     : Genereted random line direction over a unit half-sphere using the van der Corput sequence
    varioFFT2D_dl.m : Compute variograms, cross-variograms, covariograms, directional asymmetry,... using FFT.

4- The folder named 'mrst-2020a' contains the Matlab Reservoir Simulation Toolbox

5- The folder named 'Reference' contains the reference function to generete the five cases

6- The folder named 'Results' keeps the results for each case.
    
    
    
    

  