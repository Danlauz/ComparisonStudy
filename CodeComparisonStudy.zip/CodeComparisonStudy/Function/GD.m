function [Z,Err,Delta,Iter]=GD(x0,model,c,nbsim,zHD,LocHD,nbOpt,MaxIter,type,OFmin,seed,ConstantData)
% Generated calibrated Gaussian random field using the gradual deformation
% method

% WARNING: FFTMA is used to simulate the Gaussian random field.
% Simulated field is  (nx+a)*(ny+a) where a is the maximum
% effective range of differents models components.
% Thus, avoid models with large range.

    %input:
    %x0 -- Grid (nbpoint x dim)
    %model -- covariance model
    %c -- sill (one for each model)
    %nbsim -- number of simulation
    %zHD --   values of hard data  (nbHDx1)
    %LocHD -- localization of hard data (nbHDx1)
    %nbOpt -- number of optimization done
    %type -- Objective function to evaluate
    %OFmin -- minimum objective function value to reach
    %seed -- for reproductability
    
    %return:
    %Z  -- Calibrated Random Gaussian field
    %Err  -- Objective function value
    %Delta  -- Mean pixel perturbation
    %Iter  -- Number of iteration performed
    
    % Authors : Dany Lauzon

%Dimension of the grid
n=max(x0);
nx=n(1);ny=n(2);nz=n(3);

%1-covariance matrix for the post-conditioning
x0init=x0;
k=covardm(x0(LocHD,1:3),x0(LocHD,1:3),model,c);
ki=inv(k);
k0=covardm(x0(LocHD,1:3),x0,model,c);

%nbsim simuation
parfor j=1:nbsim
    %For reproductability
    rng('default')
    rng(j+seed);
    %Initialization
    err=nan(nbOpt,1);errNow=1000;
    delta=nan(nbOpt,1);
    x0=x0init;
    %2- Starting Gaussian random field
    [zsim]=FFTMA(model,c,seed+j,1,nx,1,ny,1,nz,1);
    %Post-conditioning
    if ~isempty(LocHD)
        zsim= postcond( [x0(LocHD,:) ,zHD] , [x0(LocHD,:) , zsim(LocHD,:)], [x0 ,zsim] , 1 , ki ,k0 );
        zsim=zsim(:,end);
    end
    %3- Gaussian random field to be combined
    znew= FFTMA(model,c,seed+(j-1)*nbOpt+1,nbOpt,nx,1,ny,1,nz,1);
    %Post-conditioning
    if ~isempty(LocHD)
        znew= postcond( [x0(LocHD,:) ,zHD] , [x0(LocHD,:) , znew(LocHD,:)], [x0 ,znew] , 1 , ki ,k0 );
        znew=znew(:,end-nbOpt+1:end);
    end

    %Optimization on parameter t
    for i=1:nbOpt
        %4- Optimization of the objective function
        options=optimset('MaxIter',MaxIter,'TolX',10^-8,'Display','off');
        func = @(t) OptErr(t,x0,zsim,znew(:,i),zHD,LocHD,ki,k0,type,ConstantData,j);
        X=0;
        X=[X-1 X+1]*1.5*pi; %Enlarged the seach space in [-1.5pi 1.5pi] to avoid being trap in the boudaries [-*pi *pi]
        [t,errNew] = fminbnd(func,X(1),X(2),options);
        
        %5-Update
        zsim_previous=zsim;
        zsim_new=zsim*cos(t)+znew(:,i)*sin(t);

        %Post-conditioning
        if ~isempty(LocHD)
            zsim_new= postcond( [x0(LocHD,:) ,zHD] , [x0(LocHD,:) , zsim_new(LocHD,:)], [x0 ,zsim_new] , 1 , ki ,k0 );
            zsim_new=zsim_new(:,end);
        end
        
        %Compute the average pixel perturbation from zsim_previous to zsim_New
        delta(i)=mean(abs(zsim_previous-zsim_new));
        
        %6-Keep the best solution
        if errNew<=errNow
            zsim=zsim_new;
            errNow=errNew;
        end
        err(i)=errNow;
        
        % check stopping criteria
        if errNow<=OFmin
            break;
        end
    end
    %7- Return Z and other parameters
    Z(:,j)=zsim;
    Iter(j)=i;
    Err(:,j)=err;
    Delta(:,j)=delta;
end

function err=OptErr(t,x0,zsim,znew,zHD,LocHD,ki,k0,type,ConstantData,j)

zsim=zsim*cos(t)+znew*sin(t);

if ~isempty(LocHD)
    zsim= postcond( [x0(LocHD,:) ,zHD] , [x0(LocHD,:) , zsim(LocHD,:)], [x0 ,zsim] , 1 , ki ,k0 );
    zsim=zsim(:,end);
end
err=ObjectiveFunction(zsim,type,ConstantData,j);