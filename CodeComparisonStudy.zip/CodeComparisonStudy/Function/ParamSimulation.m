function [model,c,nx,ny,nz,zHD,LocHD,nbiter,nbsim,OFmin,seed,ConstantData]=ParamSimulation(type)

switch type
        case 1 % Maximum value around a node
        load 'Data/Ex1_Data.mat' zHD LocHD ConstantData
        model=[2 5 5 5 0 0 0]; c=1; %Covariance function (exponential isotropic a=10)
        nbsim=500; %number of realization performed
        nx=21; ny=20; nz=1; %dimension of the field (fix nz=1)
        nbiter=2000;
        seed=42539;
        OFmin=0;
        
    case 2 % Alternative to the Gibbs sampler using calibration
        load 'Data/Ex2_Data.mat' zHD LocHD ConstantData
        model=[ 3 6 6 6 0 0 0]; c=1; %Covariance function (gaussian isotropic a=6)
        nbsim=2000; %number of realization performed
        nx=50; ny=31; nz=1; %dimension of the field (fix nz=1)
        nbiter=2000;
        seed=845215;
        OFmin=0;
        
    case 3 % Exemple 1 : MRST - Hydraulic head and pumping test
        load 'Data/Ex3_Data.mat' zHD LocHD ConstantData
        model=[ 4 40 20 20 0 0 0]; c=1; %Covariance function (spherical anisotropic a0=40, a90=20)
        nbsim=100; %number of realization performed
        nx=101; ny=101; nz=1; %dimension of the field (fix nz=1)
        nbiter=250;
        seed=12512;
        OFmin=0;
        
    case 4 % Exemple 2 : MRST - Time-of-flight (Truncated Gaussian case)
        load 'Data/Ex4_Data.mat' zHD LocHD ConstantData
        model=[6 15 25 15 0 0 30]; c=1; %Covariance function (cubic anisotropic a30=15, a120=25)
        nbsim=100; %number of realization performed
        nx=101; ny=101; nz=1; %dimension of the field (fix nz=1)
        nbiter=2000;
        seed=85695;
        OFmin=0;

    case 5 % Exemple 5 : Synthetic Assymetry
        load 'Data/Ex5_Data.mat' zHD LocHD ConstantData
        model=[4 10 10 10 0 0 0]; c=1;%Covariance function (spherical isotropic a=10)
        nbsim=100; %number of realization performed
        nx=100; ny=100; nz=1;%dimension of the field (fix nz=1)
        nbiter=4000;
        seed=98653;
        OFmin=0;
        
    case 99 % Test
        zHD=[];
        LocHD=[];
        model=[ 4 10 30 10 0 0 0; 6 10 30 10 0 0 0]; c=[1;1]; %Covariance function (spherical anisotropic a134=22.28, a44=12.15)
        nbsim=400; %number of realization performed
        nx=40; ny=40; nz=1; %dimension of the field (fix nz=1)
        nbiter=2000;
        seed=4512;
        OFmin=0;
    otherwise
        warning('Invalid value type. No example for this number.')
end
