function [Z,Err,Delta,Iter]=ISR(x0,model,c,nbsim,zHD,LocHD,nbOpt,phiMax,coef,type,OFmin,seed,ConstantData)
% Generated calibrated Gaussian random field using the iterative spatial
% resampling method.

% WARNING: FFTMA is used to simulate the Gaussian random field.
% Simulated field is  (nx+a)*(ny+a) where a is the maximum
% effective range of differents models components.
% Thus, avoid models with large range.

    %input:
    %x0  -- Grid (nbpoint x dim)
    %model -- covariance model
    %c -- sill (one for each model)
    %nbsim -- number of simulation
    %zHD --   values of hard data  (nbHDx1)
    %LocHD -- localization of hard data (nbHDx1)
    %nbOpt -- number of optimization done
    %nbPoint -- percentage of point keep from previous field
    %type -- Objective function to evaluate
    %OFmin -- minimum objective function value to reach
    %seed -- for reproductability
    
    %return:
    %Z  -- Calibrated Random Gaussian field
    %Err  -- Objective function value
    %Delta  -- Mean pixel perturbation
    %Iter  -- Number of iteration performed

%Dimension of the grid    
n=max(x0);
nx=n(1); ny=n(2); nz=n(3);

%1-covariance matrix for ISR method and the post-conditioning
x0init=x0;
Kinit=covardm(x0(:,1:3),x0(:,1:3),model,c);
K0init=covardm(x0(:,1:3),x0,model,c);

phiMaxinit=phiMax;
%nbsim simuation
parfor j=1:nbsim
    %For reproductability
    rng('default')
    rng(j+seed);
    
    %Initialization
    err=nan(nbOpt,1);errNow=1000;
    delta=nan(nbOpt,1);
    K=Kinit;
    K0=K0init;
    x0=x0init;
    phiMax=phiMaxinit;
    %2- Starting Gaussian random field
    [zsim]=FFTMA(model,c,seed+j,1,nx,1,ny,1,nz,1);
    
    k=K(LocHD,LocHD);
    ki=inv(k);
    k0=K0(LocHD,:);
    %Post-conditioning
    if ~isempty(LocHD)
        zsim= postcond( [x0(LocHD,:) ,zHD] , [x0(LocHD,:) , zsim(LocHD,:)], [x0 ,zsim] , 1 , ki,k0 );
        zsim=zsim(:,end);
    end
    %3- Gaussian random field to be combined
    znew= FFTMA(model,c,seed+(j-1)*nbOpt+1,nbOpt,nx,1,ny,1,nz,1);
    %Post-conditioning
    if ~isempty(LocHD)
        znew= postcond( [x0(LocHD,:) ,zHD] , [x0(LocHD,:) , znew(LocHD,:)], [x0 ,znew] , 1 , ki,k0 );
        znew=znew(:,end-nbOpt+1:end);
    end

    ii=0;
    %ISR method
    for i=1:nbOpt  
        %Number of point keep from the previous field
        nbPoint=1+floor(phiMax*(1-coef^i)*size(x0,1));
        %Sample randomly the grid
        idx=randperm(size(x0,1),nbPoint);
        PosISR=unique([LocHD;idx']);
        
        %4-covariance matrix for the post-conditioning
        k=K(PosISR,PosISR);
        ki=inv(k);
        k0=K0(PosISR,:);
        %5- ISR
        zsim_new= postcond( [x0(PosISR,:) ,zsim(PosISR)] , [x0(PosISR,:) , znew(PosISR,i)], [x0 ,znew(:,i)] , 1 , ki ,k0 );
        zsim_new=zsim_new(:,end);
        %6- Objective Function
        errNew=ObjectiveFunction(zsim_new,type,ConstantData,j);
        
        %Compute the average pixel perturbation from zsim_previous to zsim_New
        zsim_previous=zsim;
        delta(i)=mean(abs(zsim_previous-zsim_new));
        
        %7-Keep the best solution
        if errNew<=errNow
            zsim=zsim_new;
            errNow=errNew;
            ii=ii+1;
        end
        err(i)=errNow;
        
        % check stopping criteria
        if errNow<=OFmin
            break;
        end
        
    end
    %11- Return Z and other parameters
    Z(:,j)=zsim;
    Err(:,j)=err;
    Delta(:,j)=delta;
    Iter(j)=i;
end

