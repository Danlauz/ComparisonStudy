function dkl=div_kullback_leibler(p,q)
% divergence de kullback-leibler
% p est la distribution expérimentale
% q est la distribution théorique ou prévue

dkl=sum(p.*log(p./q));