for i=1:nbiter
    x = errPA(i,:);                      % Create Data
    CIPA(i,:) =prctile(x,abs([0,100]-(100-95)/2));
end

for i=1:nbiter
    x = errISR(i,:);                      % Create Data
    CIISR(i,:) =prctile(x,abs([0,100]-(100-97.5)/2));
end

for i=1:nbiter/MaxIterGD
    x = errGD(i,:);                      % Create Data
    CIGD(i,:) =prctile(x,abs([0,100]-(100-97.5)/2));
end

for i=1:nbiter/MaxIterSSTBM
    x = errSSTBM(i,:);                      % Create Data
    CISSTBM(i,:) =prctile(x,abs([0,100]-(100-97.5)/2));
end

for i=1:nbiter
    x = errFFTMASA(i,:);                      % Create Data
    CIFFTMASA(i,:) =prctile(x,abs([0,100]-(100-97.5)/2));
end