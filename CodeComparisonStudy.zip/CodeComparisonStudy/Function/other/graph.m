%%

dhcov=varioFFT2D_dl(x0,ZSimUC,1,0,0);

Cy=sum(c)-covardm(grille2(0,nx-1,1,0,0,1),[0 0],model,c);
Cx=sum(c)-covardm(grille2(0,0,1,0,ny-1,1),[0 0],model,c);


for i=1:nbsim
    intervalVy(i,:)=dhcov{i,i}(nx,ny:2*ny-1);
    intervalVx(i,:)=dhcov{i,i}(nx:2*nx-1,ny);
end
IVy95=quantile(intervalVy,0.95);
IVy05=quantile(intervalVy,0.05);
IVx95=quantile(intervalVx,0.95);
IVx05=quantile(intervalVx,0.05);


figure(1);
mean=zeros(size(dhcov{1,1}(nx,ny:2*ny-1)));
for i=1:nbsim
    plot([0:ny-1],dhcov{i,i}(nx,ny:2*ny-1),'Color', [0.7 0.7 0.7]);
    mean=mean+dhcov{i,i}(nx,ny:2*ny-1)/nbsim;
    hold on
end

plot([0:ny-1],IVy95,'k','LineWidth',2);
hold on
plot([0:ny-1],IVy05,'k','LineWidth',2);
hold on
plot([0:ny-1],mean,'k*');
hold on
plot([0:ny-1],Cx,'r');

xlabel('Distance h','FontSize',12)
ylabel('Variogram value','FontSize',12)
xlim([0 40])
ylim([0 2*sum(c)])

figure(2);
mean=zeros(size(dhcov{1,1}(nx:2*nx-1,ny)));
for i=1:nbsim
    plot([0:nx-1],dhcov{i,i}(nx:2*nx-1,ny),'Color', [0.7 0.7 0.7]);
    mean=mean+dhcov{i,i}(nx:2*nx-1,ny)/nbsim;
    hold on
end
plot([0:nx-1],IVx95,'--k','LineWidth',2);
hold on
plot([0:nx-1],IVx05,'--k','LineWidth',2);
hold on
plot([0:nx-1],mean,'k*');
hold on
plot([0:ny-1],Cy,'r');

xlabel('Distance h','FontSize',12)
ylabel('Variogram value','FontSize',12)
xlim([0 40])
ylim([0 2*sum(c)])

