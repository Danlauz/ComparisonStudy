%% S-STBM
type=1

clearvars -except type
[model,c,nx,ny,nz,zHD,LocHD,nbiter,nbsim,OFmin,seed,ConstantData]=ParamSimulation(type);
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid
saveData='true'; %Save the data
    
MaxIterSSTBM=2;nl=nbiter/MaxIterSSTBM;
tic
[ZSimSSTBM2,errSSTBM2,deltaSSTBM2]=S_STBM(x0,model,c,nbsim,zHD,LocHD,nl,MaxIterSSTBM,type,OFmin,seed,ConstantData);
tSSTBM=toc/nbsim

MaxIterSSTBM=5;nbOpt=nbiter/MaxIterSSTBM;nl=nbiter/MaxIterSSTBM;
tic
[ZSimSSTBM5,errSSTBM5,deltaSSTBM5]=S_STBM(x0,model,c,nbsim,zHD,LocHD,nl,MaxIterSSTBM,type,OFmin,seed,ConstantData);
tSSTBM=toc/nbsim

MaxIterSSTBM=10;nbOpt=nbiter/MaxIterSSTBM;nl=nbiter/MaxIterSSTBM;
tic
[ZSimSSTBM10,errSSTBM10,deltaSSTBM10]=S_STBM(x0,model,c,nbsim,zHD,LocHD,nl,MaxIterSSTBM,type,OFmin,seed,ConstantData);
tSSTBM=toc/nbsim

MaxIterSSTBM=20;nbOpt=nbiter/MaxIterSSTBM;nl=nbiter/MaxIterSSTBM;
tic
[ZSimSSTBM20,errSSTBM20,deltaSSTBM20]=S_STBM(x0,model,c,nbsim,zHD,LocHD,nl,MaxIterSSTBM,type,OFmin,seed,ConstantData);
tSSTBM=toc/nbsim


if saveData=='true'
    save(['Results/Ex' num2str(type) '_ParametersAnalysis_SSTBM.mat']);
end
    

%% GD

clearvars -except type
[model,c,nx,ny,nz,zHD,LocHD,nbiter,nbsim,OFmin,seed,ConstantData]=ParamSimulation(type);
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid
saveData='true'; %Save the data
    
MaxIterGD=2;nbOpt=nbiter/MaxIterGD;
tic
[ZSimGD2,errGD2,deltaGD2]=GDOpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,MaxIterGD,type,OFmin,seed,ConstantData);
tGD=toc/nbsim

MaxIterGD=5;nbOpt=nbiter/MaxIterGD;
tic
[ZSimGD5,errGD5,deltaGD5]=GDOpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,MaxIterGD,type,OFmin,seed,ConstantData);
tGD=toc/nbsim

MaxIterGD=10;nbOpt=nbiter/MaxIterGD;
tic
[ZSimGD10,errGD10,deltaGD10]=GDOpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,MaxIterGD,type,OFmin,seed,ConstantData);
tGD=toc/nbsim

MaxIterGD=20;nbOpt=nbiter/MaxIterGD;
tic
[ZSimGD20,errGD20,deltaGD20]=GDOpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,MaxIterGD,type,OFmin,seed,ConstantData);
tGD=toc/nbsim

if saveData=='true'
    save(['Results/Ex' num2str(type) '_ParametersAnalysis_GD.mat']);
end

%% ISR 

% clearvars -except type
[model,c,nx,ny,nz,zHD,LocHD,nbiter,nbsim,OFmin,seed,ConstantData]=ParamSimulation(type);
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid
saveData='true'; %Save the data

nbOpt=nbiter; phiMax=10/100;coef=0;
tic
[ZSimISR10,errISR10,deltaISR10]=ISROpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,phiMax,coef,type,OFmin,seed,ConstantData);
tISR=toc/nbsim

nbOpt=nbiter; phiMax=5/100;coef=0;
tic
[ZSimISR5,errISR5,deltaISR5]=ISROpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,phiMax,coef,type,OFmin,seed,ConstantData);
tISR=toc/nbsim

nbOpt=nbiter; phiMax=1/100;coef=0;
tic
[ZSimISR1,errISR1,deltaISR1]=ISROpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,phiMax,coef,type,OFmin,seed,ConstantData);
tISR=toc/nbsim

nbOpt=nbiter; phiMax=10/100;coef=0.995;
tic
[ZSimISRc1,errISRc1,deltaISRc1]=ISROpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,phiMax,coef,type,OFmin,seed,ConstantData);
tISR=toc/nbsim

nbOpt=nbiter; phiMax=10/100;coef=0.9975;
tic
[ZSimISRc2,errISRc2,deltaISRc2]=ISROpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,phiMax,coef,type,OFmin,seed,ConstantData);
tISR=toc/nbsim

if saveData=='true'
    save(['Results/Ex' num2str(type) '_ParametersAnalysis_ISR.mat']);
end

%% PA 
type=3;
clearvars -except type
[model,c,nx,ny,nz,zHD,LocHD,nbiter,nbsim,OFmin,seed,ConstantData]=ParamSimulation(type);
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid
saveData='true'; %Save the data

nbOpt=nbiter;
Tstart=0.01;Tfac=1/1.05;Tstep=10;
Nstart=200;Nfac=1/1.05;Nstep=10;
tic
[ZSimPA1,errPA1,deltaPA1,IterPA1]=PAOpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
tPA=toc/nbsim

Tstart=0.01;Tfac=1/1.10;Tstep=10;
Nstart=200;Nfac=1/1.10;Nstep=10;
tic
[ZSimPA2,errPA2,deltaPA2,IterPA2]=PAOpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
tPA=toc/nbsim

Tstart=0.01;Tfac=1/1.20;Tstep=10;
Nstart=200;Nfac=1/1.20;Nstep=10;
tic
[ZSimPA3,errPA3,deltaPA3,IterPA3]=PAOpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
tPA=toc/nbsim

Tstart=0.01;Tfac=1/1.05;Tstep=20;
Nstart=200;Nfac=1/1.05;Nstep=20;
tic
[ZSimPA4,errPA4,deltaPA4,IterPA4]=PAOpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
tPA=toc/nbsim

Tstart=0.01;Tfac=1/1.05;Tstep=50;
Nstart=200;Nfac=1/1.05;Nstep=50;
tic
[ZSimPA5,errPA5,deltaPA5,IterPA5]=PAOpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
tPA=toc/nbsim

Tstart=0.01;Tfac=1/1.05;Tstep=10;
Nstart=500;Nfac=1/1.05;Nstep=10;
tic
[ZSimPA6,errPA6,deltaPA6,IterPA6]=PAOpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
tPA=toc/nbsim

Tstart=0.01;Tfac=1/1.05;Tstep=10;
Nstart=500;Nfac=1/1.05;Nstep=10;
tic
[ZSimPA6,errPA6,deltaPA6,IterPA6]=PAOpt(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
tPA=toc/nbsim

if saveData=='true'
    save(['Results/Ex' num2str(type) '_ParametersAnalysis_PA.mat']);
end

% FFTMA-SA

clearvars -except type
[model,c,nx,ny,nz,zHD,LocHD,nbiter,nbsim,OFmin,seed,ConstantData]=ParamSimulation(type);
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid
saveData='true'; %Save the data

nbOpt=nbiter;
Tstart=0.01;Tfac=1/1.05;Tstep=10;
Nstart=ceil(0.4*size(x0,1));Nfac=1/1.05;Nstep=10;
tic
[ZSimFFTMASA1,errFFTMASA1,deltaFFTMASA1]=FFTMASA(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
tFFTMASA=toc/nbsim

Tstart=0.01;Tfac=1/1.10;Tstep=10;
Nstart=ceil(0.4*size(x0,1));Nfac=1/1.10;Nstep=10;
tic
[ZSimFFTMASA2,errFFTMASA2,deltaFFTMASA2]=FFTMASA(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
tFFTMASA=toc/nbsim

Tstart=0.01;Tfac=1/1.20;Tstep=10;
Nstart=ceil(0.4*size(x0,1));Nfac=1/1.20;Nstep=10;
tic
[ZSimFFTMASA3,errFFTMASA3,deltaFFTMASA3]=FFTMASA(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
tFFTMASA=toc/nbsim

Tstart=0.01;Tfac=1/1.05;Tstep=20;
Nstart=ceil(0.4*size(x0,1));Nfac=1/1.05;Nstep=20;
tic
[ZSimFFTMASA4,errFFTMASA4,deltaFFTMASA4]=FFTMASA(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
tFFTMASA=toc/nbsim

Tstart=0.01;Tfac=1/1.05;Tstep=50;
Nstart=ceil(0.4*size(x0,1));Nfac=1/1.05;Nstep=50;
tic
[ZSimFFTMASA5,errFFTMASA5,deltaFFTMASA5]=FFTMASA(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
tFFTMASA=toc/nbsim

Tstart=0.01;Tfac=1/1.05;Tstep=10;
Nstart=ceil(0.8*size(x0,1));Nfac=1/1.05;Nstep=10;
tic
[ZSimFFTMASA6,errFFTMASA6,deltaFFTMASA6]=FFTMASA(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
tFFTMASA=toc/nbsim

if saveData=='true'
    save(['Results/Ex' num2str(type) '_ParametersAnalysis_FFTMASA.mat']);
end
%% FIGURE
type=5;
miny=10^-1.6; maxy=1;

load(['Results/Ex' num2str(type) '_ParametersAnalysis_SSTBM.mat']);
load(['Results/Ex' num2str(type) '_ParametersAnalysis_GD.mat']);
load(['Results/Ex' num2str(type) '_ParametersAnalysis_ISR.mat']);
load(['Results/Ex' num2str(type) '_ParametersAnalysis_PA.mat']);
load(['Results/Ex' num2str(type) '_ParametersAnalysis_FFTMASA.mat']);

if type==5
    errISR1=errISR1(1:nbiter,:);
    errISR5=errISR5(1:nbiter,:);
    errISR10=errISR10(1:nbiter,:);
    errISRc1=errISRc1(1:nbiter,:);
    errISRc2=errISRc2(1:nbiter,:);
end
OFinit1=(sum(errSSTBM2(1,:))+sum(errSSTBM5(1,:))+sum(errSSTBM10(1,:))+sum(errSSTBM20(1,:)))/nbsim/4;
OFinit2=(sum(errGD2(1,:))+sum(errGD5(1,:))+sum(errGD10(1,:))+sum(errGD20(1,:)))/nbsim/4;
OFinit3=(sum(errISR1(1,:))+sum(errISR5(1,:))+sum(errISR10(1,:))+sum(errISRc1(1,:))+sum(errISRc2(1,:)))/nbsim/5;
OFinit4=(sum(errPA1(1,:))+sum(errPA2(1,:))+sum(errPA3(1,:))+sum(errPA4(1,:))+sum(errPA5(1,:))+sum(errPA6(1,:)))/nbsim/6;
OFinit5=(sum(errFFTMASA1(1,:))+sum(errFFTMASA2(1,:))+sum(errFFTMASA3(1,:))+sum(errFFTMASA4(1,:))+sum(errFFTMASA5(1,:))+sum(errFFTMASA6(1,:)))/nbsim/6;

OFinit=(OFinit1+OFinit2+OFinit3+OFinit4+OFinit5)/5;

figure(1)
plot([0 2/2:2:nbiter],[1; mean(errSSTBM2,2,'omitnan')/OFinit],'r','Linewidth',2)
hold on
plot([0 5/2:5:nbiter],[1; mean(errSSTBM5,2,'omitnan')/OFinit],'b','Linewidth',2)
hold on
plot([0 10/2:10:nbiter],[1; mean(errSSTBM10,2,'omitnan')/OFinit],'g','Linewidth',2)
hold on
plot([0 20/2:20:nbiter],[1; mean(errSSTBM20,2,'omitnan')/OFinit],'k','Linewidth',2)
xlim([0 nbiter])
ylim([miny maxy])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend('\beta=2','\beta=5','\beta=10','\beta=20')
title('S-STBM')

figure(2)
plot([0 2/2:2:nbiter],[1; mean(errGD2,2,'omitnan')/OFinit],'r','Linewidth',2)
hold on
plot([0 5/2:5:nbiter],[1; mean(errGD5,2,'omitnan')/OFinit],'b','Linewidth',2)
hold on
plot([0 10/2:10:nbiter],[1; mean(errGD10,2,'omitnan')/OFinit],'g','Linewidth',2)
hold on
plot([0 20/2:20:nbiter],[1; mean(errGD20,2,'omitnan')/OFinit],'k','Linewidth',2)
xlim([0 nbiter])
ylim([miny maxy])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend('\beta=2','\beta=5','\beta=10','\beta=20')
title('GD')

figure(3)
plot([0:nbiter],[1;mean(errISR1,2,'omitnan')/OFinit],'r','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errISR5,2,'omitnan')/OFinit],'b','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errISR10,2,'omitnan')/OFinit],'g','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errISRc1,2,'omitnan')/OFinit],'k','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errISRc2,2,'omitnan')/OFinit],'m','Linewidth',2)
xlim([0 nbiter])
ylim([miny maxy])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend('\phi=1% ; c=0','\phi=5% ; c=0','\phi=10% ; c=0','\phi=10% ; c=0.995','\phi=10% ; c=0.9975')
title('ISR')

figure(4)

plot([0:nbiter],[1; mean(errPA1,2,'omitnan')/OFinit],'r','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errPA2,2,'omitnan')/OFinit],'b','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errPA3,2,'omitnan')/OFinit],'g','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errPA4,2,'omitnan')/OFinit],'k','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errPA5,2,'omitnan')/OFinit],'m','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errPA6,2,'omitnan')/OFinit],'c','Linewidth',2)
xlim([0 nbiter])
ylim([miny maxy])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend('#1','#2','#3','#4','#5','#6')
title('PA')

figure(5)

plot([0:nbiter],[1;mean(errFFTMASA1,2,'omitnan')/OFinit],'r','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errFFTMASA2,2,'omitnan')/OFinit],'b','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errFFTMASA3,2,'omitnan')/OFinit],'g','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errFFTMASA4,2,'omitnan')/OFinit],'k','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errFFTMASA5,2,'omitnan')/OFinit],'m','Linewidth',2)
hold on
plot([0:nbiter],[1;mean(errFFTMASA6,2,'omitnan')/OFinit],'c','Linewidth',2)
xlim([0 nbiter])
ylim([miny maxy])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend('#1','#2','#3','#4','#5','#6')
title('FFTMA-SA')