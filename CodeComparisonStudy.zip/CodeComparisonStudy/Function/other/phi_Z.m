function [Fz]=phi_Z(z,nc)
% Function to compute the quantile map phi_Z 
Fz=reshape(normcdf(z,mean(z),std(z)),nc);






