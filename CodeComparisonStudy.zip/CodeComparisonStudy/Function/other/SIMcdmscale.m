function [Metric]=SIMcdmscale(zsim,type)


switch type
    case 1 % Exemple 1 : Synthetic Assymetry
        Metric=[];
        warning('No Metric program.')
    case 2 % Alternative to the Gibbs sampler using calibration
        Metric=[];
        warning('No Metric program.')
    case 3 % Exemple 3 : MRST - Hydraulic head and pumping test
        %%% Load Data of example 3
        load 'Data/Ex3_Data.mat' ConstantData
        G=ConstantData{1};
        fluid=ConstantData{2};
        src=ConstantData{3};
        bc=ConstantData{4};
        rock=ConstantData{5};
        InitSol=ConstantData{6};
        %%% Initialization
        gravity reset off
        meanK=10;
        rock.perm=10.^(zsim-meanK);
        %%% Solve pressure equation
        % Compute transmissibilities and solve pressure equation
        T   = computeTrans(G, rock);
        sol = incompTPFA(InitSol, G, T, fluid, 'bc', bc,'src',src);
        
        Metric=sol.pressure*0.000101974; % 0.000101974 : Pa to H2O meter
        
    case 4 % Exemple 4 : MRST - Time-of-flight (Truncated Gaussian case)
        %%% Load Data of example 4
        load 'Data/Ex4_Data.mat' ConstantData
        G=ConstantData{1};
        fluid=ConstantData{2};
        src=ConstantData{3};
        bc=ConstantData{4};
        rock=ConstantData{5};
        InitSol=ConstantData{6};
        %%% Initialization
        zporo=zeros(size(zsim));
        zporo(zsim<0)=0.30;
        zporo(zsim>=0)=0.30;
        zperm=zeros(size(zsim));
        zperm(zsim<0)=125*darcy;  % clear sand
        zperm(zsim>=0)=0.8*darcy; % silty sand
        
        rock.poro=zporo;
        rock.perm=zperm;
        
        %%% Solve pressure equation
        % Compute transmissibilities and solve pressure equation
        trans  = simpleComputeTrans(G, rock);
        xr = simpleIncompTPFA(InitSol, G, trans, fluid, 'src', src,'bc',bc);
        
        h=xr.pressure*0.000101974; % 0.000101974 : Pa to H2O meter
        %%% Compute time-of-flight
        % Once the fluxes are given, the time-of-flight equation is discretized
        % with a standard upwind finite-volume method
        TOF = computeTimeOfFlight(xr, G, rock, 'src',src,'bc',bc);
        Metric=TOF/60/60/24; %/60/60/24 : sec to day
               
    case 5 % Exemple 5 : Synthetic Assymetry
        Metric=[];
        warning('No Metric program.') 
               
    otherwise
        warning('Invalid value type. No example for this number.')       
end
        