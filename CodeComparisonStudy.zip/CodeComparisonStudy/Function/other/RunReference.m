function []=RunReference(type)
switch type   
    case 1        
        Reference_Ex1_Maximum        
    case 2
        Reference_Ex2_AlternativeToGibbsSampler
    case 3
        Reference_Ex3_MRST_h
    case 4
        Reference_Ex4_MRST_TOF
    case 5
        Reference_Ex5_AsymmetrySynthetic
    otherwise
        warning('Invalid value type. No example for this number.')       
end