function [Z,Err,Delta,Iter]=FFTMASA(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData)
% Generated calibrated Gaussian random field using the Fast-Fourier
% transform moving average simulated annealing method

% WARNING: Simulated field is  (nx+a)*(ny+a) where a is the maximum
% effective range of differents models components.
% Thus, avoid models with large range.

% Generated Gaussian random field using the spectral turning band method
    %input:
    %x0  -- Grid (nbpoint x dim)
    %model -- covariance model
    %c -- sill (one for each model)
    %nbsim -- number of simulation
    %zHD --   values of hard data  (nbHDx1)
    %LocHD -- localization of hard data (nbHDx1)
    %nbPert -- Starting number of point perturbed
    %nbOpt -- number of optimization done
    %Tstart -- starting temperature
    %Tfac -- T[t] = Tstart*Tfac^t
    %Nstep   --   number of steps for each temperature
    %type -- Objective function to evaluate
    %OFmin -- minimum objective function value to reach
    %seed -- for reproductability
    
    %return:
    %Z  -- Calibrated Random Gaussian field
    %Err  -- Objective function value
    %Delta  -- Mean pixel perturbation
    %Iter  -- Number of iteration performed
    
    % Authors : Dany Lauzon

%Dimension of the grid
n=max(x0);
nx=n(1);ny=n(2);nz=n(3);

%1-covariance matrix for the post-conditioning
k=covardm(x0(LocHD,1:3),x0(LocHD,1:3),model,c);
ki=inv(k);
k0=covardm(x0(LocHD,1:3),x0,model,c);

x0init=x0;
%nbsim simuation
parfor j=1:nbsim
    %For reproductability
    rng('default')
    rng(seed+j)
    
    %Initialization
    err=nan(nbOpt,1);errBest=1000;
    delta=nan(nbOpt,1);
    x0=x0init;
    tt=0;
    nn=0;
    
    %2- Starting Gaussian random field
    [zsim,~,u,G]=FFTMA(model,c,seed+j,1,nx,1,ny,1,nz,1);
    %size of the noise matrix
    [dim_u1,dim_u2]=size(u);
    %%Post-conditioning
    if ~isempty(LocHD)
        zsim= postcond( [x0(LocHD,:) ,zHD] , [x0(LocHD,:) , zsim(LocHD,:)], [x0 ,zsim] , 1 , ki ,k0 );
        zsim=zsim(:,end);
    end
    zsim_best=zsim;
    %3-Simulated annealing on the matrix u
    iterNo=1;
    counter=[0 0 0];errNow=1000;

    while iterNo<=nbOpt
        
        TT = Tstart*Tfac^tt;
        NN = max(ceil(Nstart*Nfac^nn),1);
        %4- modification of nbp points in the random matrix u
        ui=u;
        %5-Perturnation of np normal values randomly
        id=ceil(rand([NN,1])*dim_u1*dim_u2);
        u(id)=randn([length(id),1]);
        %6-simulation
        U=fftn(u);
        GU=G.*U;
        % Inverse Fast Fourier transform
        zsim_new=real(ifftn(GU));
        zsim_new=zsim_new(1:nx,1:ny);
        zsim_new=reshape(zsim_new,nx*ny,1);

        %Post-conditioning
        if ~isempty(LocHD)
            zsim_new= postcond( [x0(LocHD,:) ,zHD] , [x0(LocHD,:) , zsim_new(LocHD,:)], [x0 ,zsim_new] , 1 , ki ,k0 );
            zsim_new=zsim_new(:,end);
        end

        %7-Objective Function
        errNew=ObjectiveFunction(zsim_new,type,ConstantData,j);
        
        %Compute the average pixel perturbation from zsim_previous to zsim_New
        zsim_previous=zsim;
        delta(iterNo)=mean(abs(zsim_previous-zsim_new));
        
        %8-Simulated Annealing
        if errNew<=errNow
            zsim=zsim_new;
            errNow=errNew;
            counter(1)=counter(1)+1;
            if errNow<=errBest
                zsim_best=zsim;
                errBest=errNow;
            end
        else
            if rand(1) < exp((errNow-errNew)/TT)
                zsim=zsim_new;
                errNow=errNew;
                counter(2)=counter(2)+1;
            else
                u=ui;
                counter(3)=counter(3)+1;
            end
        end
        %9-Annealing on temperature
        if mod(sum(iterNo),Tstep)==0
            tt =tt+1;
        end  
        %10-Annealing on the number of point to be perturbed      
        if mod(sum(iterNo),Nstep)==0
            nn =nn+1;
        end  
        
        err(iterNo)=errBest;
        
        iterNo=iterNo+1;
        
        % check stopping criteria
        if errBest<=OFmin
            break;
        end
               
    end
    %11- Return Z and other parameters
    Z(:,j)=zsim_best;
    Err(:,j)=err;
    Delta(:,j)=delta;
    Iter(j)=iterNo;
end

