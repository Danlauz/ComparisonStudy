function Z=STBM(x0,model,c,nbsim,zHD,LocHD,nl,seed)
% Generated Gaussian random field using the spectral turning band method
    %input:
    %x0  -- Grid (nbpoint x dim)
    %model -- covariance model
    %c -- sill (one for each model)
    %nbsim -- number of simulation
    %zHD --   values of hard data  (nbHDx1)
    %LocHD -- localization of hard data (nbHDx1)
    %nl -- number of lines used
    %seed -- for reproductability
    
    %return:
    %r  -- Random Gaussian field
    
    % Authors : Dany Lauzon
 
%1- Spectral density computation
[F1,s,rot,cx]=DensSpec1Ddl(x0,model,c);

%2-covariance matrix for the post-conditioning
k=covardm(x0(LocHD,1:3),x0(LocHD,1:3),model,c);
ki=inv(k);
k0=covardm(x0(LocHD,1:3),x0,model,c);


%nbsim simuation
parfor j=1:nbsim
    %Seed for reproductability
    rng('default')
    rng(seed+j);
    %Initialization 
    zsim=zeros(size(x0,1),size(F1,2));
    for k=1:size(F1,2) %Done for each covariance model.
        
        %3-Sampled random frequencies
        p=rand(nl,1);
        ul1=interp1(F1{k},s{k},p);
        
        %4-Random phases
        U=2*pi*rand(nl,1);
        
        %5-Random vector
        z=VanCorput(nl);    % Van Corput sequence
        
        %6- Frequency vector
         z1=z.*ul1;
         
         %7- Computation of each cosine function
        for i=1:nl           
            zsim(:,k)=zsim(:,k)+ sqrt(c(k))*cos((cx{k}(:,[1 2 3])*rot{k}')*z1(i,:)'+ U(i));
        end            
    end
    
    %8- Simulation zsim
    zsim=sum(zsim,2)*sqrt(2/nl);
    
    %9-Post-conditionning
    if ~isempty(LocHD)
        zsim= postcond( [x0(LocHD,:) ,zHD] , [x0(LocHD,:) , zsim(LocHD,:)], [x0 ,zsim] , 1 , ki ,k0 );
        zsim=zsim(:,end);
    end
    
    % Return Z
    Z(:,j)=zsim;
end
