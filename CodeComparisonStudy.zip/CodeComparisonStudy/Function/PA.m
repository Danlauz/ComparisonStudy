function [Z,Err,Delta,Iter] = PA(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData)

% Generated calibrated Gaussian random field using the phase annealing method.

% WARNING : Works only in 2D

% WARNING: FFTMA is used to simulate the starting Gaussian random field.
% Simulated field is  (nx+a)*(ny+a) where a is the maximum
% effective range of differents models components.
% Thus, avoid models with large range.

    %input:
    %x0  -- Grid (nbpoint x dim)
    %model -- covariance model
    %c -- sill (one for each model)
    %nbsim -- number of simulation
    %zHD --   values of hard data  (nbHDx1)
    %LocHD -- localization of hard data (nbHDx1)
    %nbP -- number of phase perturbed
    %nbOpt -- number of optimization done
    %Tstart -- starting temperature
    %Tfac -- T[t] = Tstart*Tfac^t
    %Tstep   --   number of steps for temperature T
    %Nstart -- starting temperature for nb phase perturbed
    %Nfac -- N[t] = Nstart*Nfac^t
    %Nstep   --   number of steps for temperature N
    %type -- Objective function to evaluate
    %OFmin -- minimum objective function value to reach
    %seed -- for reproductability
    
    %return:
    %Z  -- Calibrated Random Gaussian field
    %Err  -- Objective function value
    %Delta  -- Mean pixel perturbation
    %Iter  -- Number of iteration performed

%Dimension of the grid    
n=max(x0);
nx=n(1); ny=n(2);

%1-covariance matrix for the post-conditioning
k=covardm(x0(LocHD,:),x0(LocHD,:),model,c);
ki=inv(k);
k0=covardm(x0(LocHD,:),x0,model,c);

x0init=x0;
parfor j=1:nbsim
    %For reproductability
    rng('default')
    rng(j+seed);
    
    % Initialization
    errNow = 100; errBest = 100;        
    tt = 0 ;
    nn = 0 ;
    doannealing = true;
    iter = [0,0,0];
    
    err=nan(nbOpt,1);
    delta=nan(nbOpt,1);
    x0=x0init;   
    nphase          = [round(nx/2) round(ny/2)];     % nphase*2 = number of phases used

    
    %2- Enlarged the field to avoid periodicity of the FFT
    nxsim=2*nx; nysim=2*ny;
    
    %3- Starting Gaussian random field
    zsimStart=FFTMA(model,c,seed+j,1,nxsim,1,nysim,1,1,1);
    zsimStart=reshape(zsimStart,[nxsim nysim ]);
    
    % calculate spectrum
    spec = reshape(fftshift(fftn(zsimStart)),[],1);
    % amplitude spectra
    Amp = abs(spec); 
    % starting Gaussian random field
    zsim = reshape(zsimStart,[],1);
    zsim_best=zsim;
    

    while  doannealing == true 
        TT = Tstart*Tfac^tt;
        NN = max(ceil(Nstart*Nfac^nn),1);

        %4- draw npb random vectors and random phases
        rn=[randi([ceil(nxsim/2)-nphase(1), ceil(nxsim/2)+nphase(1)],NN,1) randi([ceil(nysim/2)-nphase(2), ceil(nysim/2)+nphase(2)],NN,1)];
        rnw= unique(rn(:,2)*nxsim+rn(:,1)+1,'stable');
        rnwconj= unique((nysim-rn(:,2))*nxsim+(nxsim-rn(:,1))+1,'stable');
        om_new=rand(length(rnw),1)*2*pi;
        %5- Uptade the spectrum and compute the new field
        spec_up = Amp(rnw).*exp(sqrt(-1)*om_new);
        spec_up_m = Amp(rnwconj).*exp(sqrt(-1)*(-1)*om_new);

        specNew=spec;
        specNew(rnw) = spec_up ;
        specNew(rnwconj) = spec_up_m ;
        
        zsimNew=real(ifftn(ifftshift(reshape(specNew,[nxsim,nysim]))));
        
        %Compute the average pixel perturbation from zsim_previous to zsim_New
        zsimPrevious=reshape(zsim,[nxsim,nysim]);
        pert=abs(zsimNew-zsimPrevious);
        delta(sum(iter)+1)=mean(pert(ceil(nx/2):ceil(nx/2)+nx-1,ceil(ny/2):ceil(ny/2)+ny-1),'all');
        
        %%% Annealing
        errNew=OptErr(zsimNew,zHD,LocHD,x0,ki,k0,nx,ny,nxsim,nysim,type,ConstantData,j);
        if (errNew <= errNow)
            % leave it and go on
            errNow = errNew ;
            spec(rnw) = spec_up ;
            spec(rnwconj) = spec_up_m ;
            zsim = zsimNew ;
            iter(1) = iter(1)+1 ;
            % Keep the best solution
            if errNow < errBest
                errBest = errNow;
                zsim_best=zsim;
            end
        else
            % calculate probability
            prob = exp(-(errNew - errNow)/TT);
            if rand(1) <= prob
                % leave it and go on
                errNow = errNew ;
                spec(rnw) = spec_up ;
                spec(rnwconj) = spec_up_m ;
                zsim = zsimNew ;
                iter(2) = iter(2)+1;    
            else
                % keep old spectrum and old field
                iter(3) = iter(3)+1;
            end
        end
        
        % -Annealing on temperature
        if mod(sum(iter),Tstep)==0
            tt =tt+1;
        end  
        % -Annealing on the number of phase to be perturbed      
        if mod(sum(iter),Nstep)==0
            nn =nn+1;
        end  
        
        err(sum(iter))=errBest;
        
        % check stopping criteria
        if sum(iter) >= nbOpt
            doannealing = false;
        elseif errBest<=OFmin
            doannealing = false;
        end
    end
    
    zsim=reshape(zsim_best,[nxsim nysim]);
    zsim = zsim(ceil(nx/2):ceil(nx/2)+nx-1,ceil(ny/2):ceil(ny/2)+ny-1);
    zsim=reshape(zsim,[],1);

    if ~isempty(LocHD)
        zsim= postcond( [x0(LocHD,:) ,zHD] , [x0(LocHD,:) , zsim(LocHD,:)], [x0 ,zsim] , 1 , ki ,k0 );
        zsim=zsim(:,end);
    end
    
    
    Z(:,j)=zsim;
    Err(:,j)=err;
    Delta(:,j)=delta;
    Iter(:,j)=iter';
end

function [error]=OptErr(zsim,zHD,LocHD,x0,ki,k0,nx,ny,nxsim,nysim,type,ConstantData,j)

zsim=reshape(zsim,[nxsim nysim]);
zsim = zsim(ceil(nx/2):ceil(nx/2)+nx-1,ceil(ny/2):ceil(ny/2)+ny-1);
zsim=reshape(zsim,[],1);

if ~isempty(LocHD)
    zsim= postcond( [x0(LocHD,:) ,zHD] , [x0(LocHD,:) , zsim(LocHD,:)], [x0 ,zsim] , 1 , ki ,k0 );
    zsim=zsim(:,end);
end
error=ObjectiveFunction(zsim,type,ConstantData,j);