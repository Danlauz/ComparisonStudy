function err=ObjectiveFunction(zsim,type,ConstantData,NoSim)

switch type
    case 1 % Maximum value around a node 
        %%% Init Data of example 1
        maxRef=ConstantData{1};
        LocData=ConstantData{2};
        nbData=length(LocData);
        maxSim=zeros(size(nbData));
        for i=1:nbData
            maxSim(i)=max(zsim(LocData{i}),[],'all');
        end
        err= sqrt( mean ( (maxSim-maxRef).^2 ) );
        
    case 2 % Alternative to the Gibbs sampler using calibration 
        %%% Init Data of example 2
        numsim=NoSim;
        lb=ConstantData{1}(:,numsim);
        ub=ConstantData{2}(:,numsim);
        varRef=ConstantData{3}(numsim);
        LocData=ConstantData{4};
        varSim=var(zsim);
        
        err= max(max(zsim(LocData')- lb ,0))+...
            max(max( ub-zsim(LocData') ,0))+...
            0.01*abs(varRef-varSim);

    case 3 % Exemple 1 : MRST - Hydraulic head and pumping test
        %%% Init Data of example 3
        G=ConstantData{1};
        fluid=ConstantData{2};
        src=ConstantData{3};
        bc=ConstantData{4};
        rock=ConstantData{5};
        InitSol=ConstantData{6};
        LocData=ConstantData{7};
        hData=ConstantData{8};
        
        %%% Initialization
        gravity reset off
        meanK=10;
        rock.perm=10.^(zsim-meanK);
        %%% Solve pressure equation
        % Compute transmissibilities and solve pressure equation
        T   = computeTrans(G, rock);
        sol = incompTPFA(InitSol, G, T, fluid, 'bc', bc,'src',src);
        
        hsim=sol.pressure(LocData)*0.000101974; % 0.000101974 : Pa to H2O meter
        %%% Compute root-mean-square error
        err= immse(hsim,hData);
        
    case 4 % Exemple 4 : MRST - Time-of-flight (Truncated Gaussian case)
        %%% Init Data of example 4
        G=ConstantData{1};
        fluid=ConstantData{2};
        src=ConstantData{3};
        bc=ConstantData{4};
        rock=ConstantData{5};
        InitSol=ConstantData{6};
        LocProd=ConstantData{7};
        tData=ConstantData{8};
        %%% Initialization
        zporo=zeros(size(zsim));
        zporo(zsim<0)=0.30;
        zporo(zsim>=0)=0.30;
        zperm=zeros(size(zsim));
        zperm(zsim<0)=125*darcy;  % clear sand
        zperm(zsim>=0)=0.8*darcy; % silty sand
        
        rock.poro=zporo;
        rock.perm=zperm;
        
        %%% Solve pressure equation
        % Compute transmissibilities and solve pressure equation
        trans  = simpleComputeTrans(G, rock);
        xr = simpleIncompTPFA(InitSol, G, trans, fluid, 'src', src,'bc',bc);
        
        %%% Compute time-of-flight
        % Once the fluxes are given, the time-of-flight equation is discretized
        % with a standard upwind finite-volume method
        TOF = computeTimeOfFlight(xr, G, rock, 'src',src,'bc',bc);
        tsim=TOF(LocProd )/60/60/24; %/60/60/24 : sec to day
        %%% Compute root-mean-square error
        err= immse(tsim,tData);
        
        
    case 5 % Exemple 5 : Synthetic Assymetry
        %%% Init Data of example 5
        x0=ConstantData{1};
        AssRef=ConstantData{2};
        %Compute Assymetry from simulation
        AssSim=varioFFT2D_dl( x0 , zsim , [8 3] , 0 , 0 );
        %%% Compute root-sum-square error 
        err= sqrt(sum(sum( ((AssSim{1}(75:5:end-74,75:5:end-74)-AssRef{1}(75:5:end-74,75:5:end-74)).^2) )));
    case 99 % Test
        err=1;
        
    otherwise
        warning('Invalid value type. No example for this number.')       
end
     
