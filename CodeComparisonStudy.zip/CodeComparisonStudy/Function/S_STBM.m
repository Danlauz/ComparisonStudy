function [Z,Err,Delta,Phi,Iter]=S_STBM(x0,model,c,nbsim,zHD,LocHD,nl,MaxIter,type,OFmin,seed,ConstantData)
% Generated calibrated Gaussian random field using the sequential spectral turning band method
    %input:
    %x0  -- Grid (nbpoint x dim)
    %model -- covariance model
    %c -- sill (one for each model)
    %nbsim -- number of simulation
    %zHD --   values of hard data  (nbHDx1)
    %LocHD -- localization of hard data (nbHDx1)
    %nl -- number of lines calibrated
    %MaxIter -- maximum number of iteration for the optimizer
    %OFmin -- minimum objective function value to reach
    %type -- Objective function to evaluate
    %seed -- for reproductability
    
    %return:
    %Z  -- Calibrated Random Gaussian field
    %Err  -- Objective function value
    %Delta  -- Mean pixel perturbation
    %Phi  -- vector of optimized phase
    %Iter  -- Number of iteration performed
    
    % Authors : Dany Lauzon
    
%1- Spectral density computation
[F1init,sinit,rot,cx]=DensSpec1Ddl(x0,model,c);

%2-covariance matrix for the post-conditioning
k=covardm(x0(LocHD,:),x0(LocHD,:),model,c);
ki=inv(k);
k0=covardm(x0(LocHD,:),x0,model,c);

%nbsim simuation

parfor j=1:nbsim
    %For reproductability
    rng('default')
    rng(2*j+seed);
    %Initialization
    F1=F1init;
    s=sinit;
    z1=cell(size(F1init,2),1);
    zsim=zeros(size(x0,1),1);zsimk=zeros(size(x0,1),size(F1,2)); zsimBest=zeros(size(x0,1),1);
    err=nan(nl,1); errNow=1000;
    delta=nan(nl,1);
    phi=nan(nl,1);
    
    for k=1:size(F1,2) %Done for each covariance model.
        %3-Sampled random frequencies
        p=rand(nl,1);
        ul1=interp1(F1{k},s{k},p); % interpolate ul from p and cum       
        %4-Random vector
        z=VanCorput(nl);    % Van Corput sequence
        %5- Frequency vector
        z1{k}=z.*ul1;
    end
    %Optimization on phase U
    for i=1:nl       
        %6- Calibration process on the phase U
        options=optimset('MaxIter',MaxIter,'TolX',10^-8,'Display','off');
        func = @(Uopt) OptErr(Uopt,i,x0,zsim,zsimk,c,cx,rot,z1,zHD,LocHD,ki,k0,type,ConstantData,j);
        X=rand(); X=[X-0.5 X+0.5];
        [Uopt,errNew] = fminbnd(func, X(1),X(2),options);
        
        %7-Update
        zsim_previous=zsim;        
        for k=1:size(F1,2) %Done for each covariance model.
            zsimk(:,k)=sqrt(2)*sqrt(c(k))*cos((cx{k}(:,[1 2 3])*rot{k}')*z1{k}(i,:)'+ 2*pi*Uopt);
        end
        zsim=zsim*sqrt((i-1)/i)+sum(zsimk,2)*sqrt(1/i);
        if ~isempty(LocHD)
            zsim= postcond( [x0(LocHD,:) ,zHD] , [x0(LocHD,:) , zsim(LocHD,:)], [x0 ,zsim] , 1 , ki ,k0 );
            zsim=zsim(:,end);
        end
        zsim_new=zsim;        
        %Compute the average pixel perturbation from zsim_previous to zsim_New
        delta(i)=mean(abs(zsim_previous-zsim_new));
        phi(i)=Uopt;
        %8-Keep the best solution
        if errNew<=errNow
            errNow=errNew;
            zsimBest=zsim;
        end
        err(i)=errNow;
        
        % check stopping criteria
        if errNow<=OFmin
            break;
        end
        
    end
    %9- Return Z and other parameters
    Err(:,j)=err;
    Z(:,j)=zsimBest;
    Delta(:,j)=delta;
    Phi(:,j)=phi;
    Iter(j)=i;
end

function [error]=OptErr(U,i,x0,zsim,zsimk,c,cx,rot,z1,zHD,LocHD,ki,k0,type,ConstantData,j)

for k=1:size(z1,2) %Done for each covariance model.
    zsimk(:,k)=sqrt(2)*sqrt(c(k))*cos((cx{k}(:,[1 2 3])*rot{k}')*z1{k}(i,:)'+ 2*pi*U);
end
zsim=zsim*sqrt((i-1)/i)+sum(zsimk,2)*sqrt(1/i);

if ~isempty(LocHD)
    zsim= postcond( [x0(LocHD,:) ,zHD] , [x0(LocHD,:) , zsim(LocHD,:)], [x0 ,zsim] , 1 , ki ,k0 );
    zsim=zsim(:,end);
end
error=ObjectiveFunction(zsim,type,ConstantData,j);
