%%Loading Results and reference
type=4;
load(['Results/Ex' num2str(type) '.mat']);
load(['Data/Ex' num2str(type) '_Data.mat'],'zrefGaus','LocProd','LocInj','x0','zperm');
%% Figure reference

figure(7);
imagesc(reshape(zperm,[nx ny]));set(gca,'YDir','normal'); colormap([1 1 1 ; 0.6 0.6 0.6]);
hold on
plot(x0(5101,2),x0(5101,1),'ok','MarkerSize',8,'LineWidth',2)
hold on 
plot(x0(5101,2),x0(5101,1),'xk','MarkerSize',8,'LineWidth',2)
hold on 
plot(x0(LocProd,2),x0(LocProd,1),'xk','MarkerSize',8,'LineWidth',2)
hold on 
text(x0(LocProd(1),2)-7,x0(LocProd(1),1)+5.5,'P1','Color','black','FontSize',16,'FontWeight','bold')
hold on 
text(x0(LocProd(2),2)+1,x0(LocProd(2),1)-3,'P2','Color','black','FontSize',16,'FontWeight','bold')
hold on 
text(x0(LocProd(3),2)-7,x0(LocProd(3),1)+5,'P3','Color','black','FontSize',16,'FontWeight','bold')
hold on 
text(x0(LocProd(4),2)+1,x0(LocProd(4),1)-3,'P4','Color','black','FontSize',16,'FontWeight','bold')
hold on 
text(x0(LocInj(1),2)+3,x0(LocInj(1),1)+2,'I','Color','black','FontSize',20,'FontWeight','bold')
xlabel('Coord. x','FontSize',14);
ylabel('Coord. y','FontSize',14);
%% Figure Objective function evolution and quantiles
CI95
OFinit=(sum(errSSTBM(1,:))+sum(errGD(1,:))+sum(errISR(1,:))+sum(errPA(1,:))+sum(errFFTMASA(1,:)))/nbsim/5;
figure(2) 
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],mean(errSSTBM,2,'omitnan')/OFinit,'k','Linewidth',2);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],mean(errGD,2,'omitnan')/OFinit,'b','Linewidth',2);
hold on
p3=plot(mean(errISR,2,'omitnan')/OFinit,'r','Linewidth',2);
hold on
p4=plot(mean(errPA,2,'omitnan')/OFinit,'g','Linewidth',2);
hold on
p5=plot(mean(errFFTMASA,2,'omitnan')/OFinit,'m','Linewidth',2);
xlim([0 nbiter])
ylim([10^-5 1])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')

figure(3)
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],CISSTBM(:,1)/OFinit,'--k','Linewidth',1);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],CIGD(:,1)/OFinit,'--b','Linewidth',1);
hold on
p3=plot(CIISR(:,1)/OFinit,'--r','Linewidth',1);
hold on
p4=plot(CIPA(:,1)/OFinit,'--g','Linewidth',1);
hold on
p5=plot(CIFFTMASA(:,1)/OFinit,'--m','Linewidth',1);
hold on
plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],CISSTBM(:,2)/OFinit,'--k','Linewidth',1)
hold on
plot([MaxIterGD/2:MaxIterGD:nbiter],CIGD(:,2)/OFinit,'--b','Linewidth',1)
hold on
plot(CIISR(:,2)/OFinit,'--r','Linewidth',1)
hold on
plot(CIPA(:,2)/OFinit,'--g','Linewidth',1)
hold on
plot(CIFFTMASA(:,2)/OFinit,'--m','Linewidth',1)
xlim([0 nbiter])
ylim([10^-9 1])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')

%% Boxplot misfit 

ZSimALL=[zrefGaus ZSimSSTBM ZSimGD  ZSimISR  ZSimPA ZSimFFTMASA ZSimUC];

for i=1:size(ZSimALL,2)
    h(:,i)=SIMcdmscale(ZSimALL(:,i),type);
end
%%
dist=nan(size(ZSimALL,2),size(ZSimALL,2));
for ii=1:size(ZSimALL,2)
    for jj=ii:size(ZSimALL,2)
        dist(ii,jj)=sqrt(mean((h(LocProd,ii)-h(LocProd,jj)).^2));
        dist(jj,ii)=dist(ii,jj);
    end
end
%%
figure(23)
boxplot([dist(1,0*nbsim+2:1*nbsim+1)',dist(1,1*nbsim+2:2*nbsim+1)',dist(1,2*nbsim+2:3*nbsim+1)',dist(1,3*nbsim+2:4*nbsim+1)',dist(1,4*nbsim+2:5*nbsim+1)',dist(1,5*nbsim+2:6*nbsim+1)'],'Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC'},'Whisker',1)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
ylabel('Average travel time misfit (day)')

%% Table values
for i=1:nbsim
tC(i)=h(LocProd(1),0*nbsim+1+i);
tGD(i)=h(LocProd(1),1*nbsim+1+i);
tISR(i)=h(LocProd(1),2*nbsim+1+i);
tPA(i)=h(LocProd(1),3*nbsim+1+i);
tfftmaSA(i)=h(LocProd(1),4*nbsim+1+i);
tUC(i)=h(LocProd(1),5*nbsim+1+i);
end
[mean(tC) mean(tGD) mean(tISR) mean(tPA) mean(tfftmaSA) mean(tUC)]
[std(tC) std(tGD) std(tISR) std(tPA) std(tfftmaSA) std(tUC)]

for i=1:nbsim
tC(i)=h(LocProd(2),0*nbsim+1+i);
tGD(i)=h(LocProd(2),1*nbsim+1+i);
tISR(i)=h(LocProd(2),2*nbsim+1+i);
tPA(i)=h(LocProd(2),3*nbsim+1+i);
tfftmaSA(i)=h(LocProd(2),4*nbsim+1+i);
tUC(i)=h(LocProd(2),5*nbsim+1+i);
end
[mean(tC) mean(tGD) mean(tISR) mean(tPA) mean(tfftmaSA) mean(tUC)]
[std(tC) std(tGD) std(tISR) std(tPA) std(tfftmaSA) std(tUC)]

for i=1:nbsim
tC(i)=h(LocProd(3),0*nbsim+1+i);
tGD(i)=h(LocProd(3),1*nbsim+1+i);
tISR(i)=h(LocProd(3),2*nbsim+1+i);
tPA(i)=h(LocProd(3),3*nbsim+1+i);
tfftmaSA(i)=h(LocProd(3),4*nbsim+1+i);
tUC(i)=h(LocProd(3),5*nbsim+1+i);
end
[mean(tC) mean(tGD) mean(tISR) mean(tPA) mean(tfftmaSA) mean(tUC)]
[std(tC) std(tGD) std(tISR) std(tPA) std(tfftmaSA) std(tUC)]

for i=1:nbsim
tC(i)=h(LocProd(4),0*nbsim+1+i);
tGD(i)=h(LocProd(4),1*nbsim+1+i);
tISR(i)=h(LocProd(4),2*nbsim+1+i);
tPA(i)=h(LocProd(4),3*nbsim+1+i);
tfftmaSA(i)=h(LocProd(4),4*nbsim+1+i);
tUC(i)=h(LocProd(4),5*nbsim+1+i);
end
[mean(tC) mean(tGD) mean(tISR) mean(tPA) mean(tfftmaSA) mean(tUC)]
[std(tC) std(tGD) std(tISR) std(tPA) std(tfftmaSA) std(tUC)]
%% absolut mean perturbation

figure(6) 
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],mean(deltaSSTBM,2,'omitnan'),'k','Linewidth',2);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],mean(deltaGD,2,'omitnan'),'b','Linewidth',2);
hold on
p3=plot(mean(deltaISR,2,'omitnan'),'r','Linewidth',2);
hold on
p4=plot(mean(deltaPA,2,'omitnan'),'g','Linewidth',2);
hold on
p5=plot(mean(deltaFFTMASA,2,'omitnan'),'m','Linewidth',2);
xlim([0 nbiter])
ylim([10^-3.5 1])
xlabel('number of OF evaluation i')
ylabel('Mean absolute perturbation')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')
%%
[mean(std(ZSimSSTBM')) mean(std(ZSimGD')) mean(std(ZSimISR')) mean(std(ZSimPA')) mean(std(ZSimFFTMASA'))]