%%Loading Results and reference
type=2;
load(['Results/Ex' num2str(type) '.mat']);
load(['Data/Ex' num2str(type) '_Data.mat'],'zrefGaus','x0','LocData');
%% Figure reference
sim=6;
zrefInd=nan(length(zrefGaus(:,sim)),1);
zrefInd(zrefGaus(:,sim)<=quantile(zrefGaus(:,sim),0.5))=2;
zrefInd(zrefGaus(:,sim)>quantile(zrefGaus(:,sim),0.5))=1;

figure(3)
imagesc(reshape(zrefInd,[nx ny]))
hold on
plot([11 11],[0 51],'-k','Linewidth',1.5)
hold on
plot([21 21],[0 51],'-k','Linewidth',1.5)
hold on
plot(x0(LocData([25 75]),2),x0(LocData([25 75]),1),'ok','Linewidth',2)
hold on
plot(x0(775,2),x0(775,1),'*k','Linewidth',1.2)
text(x0(LocData([25]),2)+0.2,x0(LocData([25]),1)+2,'x_n_1^j','FontSize',16, 'FontWeight', 'Bold','Color','black')
text(x0(LocData([75]),2)+0.2,x0(LocData([75]),1)+2,'x_n_2^j','FontSize',16, 'FontWeight', 'Bold','Color','black')
text(x0(775,2)+0.2,x0(775,1)+2,'x_0^j','FontSize',16, 'FontWeight', 'Bold','Color','black')
set(gca,'YDir','normal')
colormap([1 1 1 ; 0.6 0.6 0.6])
xlabel('Coord. x','FontSize',14);
ylabel('Coord. y','FontSize',14);

%% Figure Objective function evolution and quantiles
OFinit=(sum(errSSTBM(1,:))+sum(errGD(1,:))+sum(errISR(1,:))+sum(errPA(1,:))+sum(errFFTMASA(1,:)))/nbsim/5;
figure(2) 
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],mean(errSSTBM,2,'omitnan')/OFinit,'k','Linewidth',2);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],mean(errGD,2,'omitnan')/OFinit,'b','Linewidth',2);
hold on
p3=plot(mean(errISR,2,'omitnan')/OFinit,'r','Linewidth',2);
hold on
p4=plot(mean(errPA,2,'omitnan')/OFinit,'g','Linewidth',2);
hold on
p5=plot(mean(errFFTMASA,2,'omitnan')/OFinit,'m','Linewidth',2);
xlim([0 nbiter])
ylim([10^-3.5 1])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')

%% Average triplet probability misfit
kk=0;
for point1=[1:500 551:1000 1051:1550]
    kk=kk+1
    F1=501+mod(point1-1,50);
    F2=1001+mod(point1-1,50);
    mu = [0 0 0];
    Sigma = [covardm(x0(F1,1:3),x0(F1,1:3),model,c) covardm(x0(F1,1:3),x0(F2,1:3),model,c) covardm(x0(F1,1:3),x0(point1,1:3),model,c);...
        covardm(x0(F2,1:3),x0(F1,1:3),model,c) covardm(x0(F2,1:3),x0(F2,1:3),model,c) covardm(x0(F2,1:3),x0(point1,1:3),model,c);...
        covardm(x0(point1,1:3),x0(F1,1:3),model,c) covardm(x0(point1,1:3),x0(F2,1:3),model,c) covardm(x0(point1,1:3),x0(point1,1:3),model,c)];
    
    [X1,X2,X3] = meshgrid(linspace(-4,4,100)',linspace(-4,4,100)',linspace(-4,4,100)');
    X = [X1(:) X2(:) X3(:)];    
    [p1,e1]=mvncdf([-inf -inf -inf],[0 0 0],mu,Sigma);
    [p2,e2]=mvncdf([-inf -inf 0],[0 0 inf],mu,Sigma);
    [p3,e3]=mvncdf([-inf 0 -inf],[0 inf 0],mu,Sigma);
    [p4,e4]=mvncdf([-inf 0 0],[0 inf inf],mu,Sigma);
    [p5,e5]=mvncdf([0 -inf -inf],[inf 0 0],mu,Sigma);
    [p6,e6]=mvncdf([0 -inf 0],[inf 0 inf],mu,Sigma);
    [p7,e7]=mvncdf([0 0 -inf],[inf inf 0],mu,Sigma);
    [p8,e8]=mvncdf([0 0 0],[inf inf inf],mu,Sigma);
    

    q=[p1 p2 p3 p4 p5 p6 p7 p8]*100;
    P3=[];
    Pref=[p1/(p1+p2) p2/(p1+p2) p3/(p3+p4) p4/(p3+p4) p5/(p5+p6) p6/(p5+p6) p7/(p7+p8) p8/(p7+p8)];
    for jj=[1:6]
        if jj==1
            ZSim=zrefGaus(:,1:nbsim);
        end
        if jj==2
            ZSim=ZSimSSTBM;
        end
        if jj==3
            ZSim=ZSimGD;
        end
        if jj==4
            ZSim=ZSimISR;
        end
        if jj==5
            ZSim=ZSimPA;
        end
        if jj==6
            ZSim=ZSimFFTMASA;
        end
        ZZind=nan(nx*ny*nz,nbsim);
        ZZind(ZSim<=0)=1;
        ZZind(ZSim>0)=2;
        PZ1=0;PZ2=0;PZ3=0;PZ4=0;PZ5=0;PZ6=0;PZ7=0;PZ8=0;
        for i=1:nbsim
            if ZZind(F1,i)==1 && ZZind(F2,i)==1 && ZZind(point1,i)==1
                PZ1=PZ1+1;
            end
            if ZZind(F1,i)==1 && ZZind(F2,i)==1 && ZZind(point1,i)==2
                PZ2=PZ2+1;
            end
            if ZZind(F1,i)==1 && ZZind(F2,i)==2 && ZZind(point1,i)==1
                PZ3=PZ3+1;
            end
            if ZZind(F1,i)==1 && ZZind(F2,i)==2 && ZZind(point1,i)==2
                PZ4=PZ4+1;
            end
            if ZZind(F1,i)==2 && ZZind(F2,i)==1 && ZZind(point1,i)==1
                PZ5=PZ5+1;
            end
            if ZZind(F1,i)==2 && ZZind(F2,i)==1 && ZZind(point1,i)==2
                PZ6=PZ6+1;
            end
            if ZZind(F1,i)==2 && ZZind(F2,i)==2 && ZZind(point1,i)==1
                PZ7=PZ7+1;
            end
            if ZZind(F1,i)==2 && ZZind(F2,i)==2 && ZZind(point1,i)==2
                PZ8=PZ8+1;
            end
        end
        PZ1=PZ1/nbsim;PZ2=PZ2/nbsim;PZ3=PZ3/nbsim;PZ4=PZ4/nbsim;
        PZ5=PZ5/nbsim;PZ6=PZ6/nbsim;PZ7=PZ7/nbsim;PZ8=PZ8/nbsim;
        
        pKL=[PZ1 PZ2 PZ3 PZ4 PZ5 PZ6 PZ7 PZ8]*100;
        
        P3=[P3 ; PZ1/(PZ1+PZ2) PZ2/(PZ1+PZ2) PZ3/(PZ3+PZ4) PZ4/(PZ3+PZ4) PZ5/(PZ5+PZ6) PZ6/(PZ5+PZ6) PZ7/(PZ7+PZ8) PZ8/(PZ7+PZ8)];
        aKL(kk,jj)=div_kullback_leibler(pKL,q);
    end  
    a3(kk,:)=mean(abs(P3-repmat(Pref,6,1)),2)'*100; 
end
%%
figure(4)
boxplot(a3(:,[2 3 4 5 6 1]),'Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC'},'Whisker',1)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
ylabel('Average triplet probability misfit (%)')

figure(5)
boxplot(aKL(:,[2 3 4 5 6 1]),'Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC'},'Whisker',1)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
ylabel('Kullback–Leibler divergence (%)')
%% absolut mean perturbation

figure(5) 
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],mean(deltaSSTBM,2,'omitnan'),'k','Linewidth',2);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],mean(deltaGD,2,'omitnan'),'b','Linewidth',2);
hold on
p3=plot(mean(deltaISR,2,'omitnan'),'r','Linewidth',2);
hold on
p4=plot(mean(deltaPA,2,'omitnan'),'g','Linewidth',2);
hold on
p5=plot(mean(deltaFFTMASA,2,'omitnan'),'m','Linewidth',2);
xlim([0 nbiter])
ylim([10^-2.7 1])
xlabel('number of OF evaluation i')
ylabel('Mean absolute perturbation')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')
%%
[mean(std(ZSimSSTBM')) mean(std(ZSimGD')) mean(std(ZSimISR')) mean(std(ZSimPA')) mean(std(ZSimFFTMASA'))]
[mean(corr(ZSimSSTBM),'all') mean(corr(ZSimGD),'all') mean(corr(ZSimISR),'all') mean(corr(ZSimPA),'all') mean(corr(ZSimFFTMASA),'all')]