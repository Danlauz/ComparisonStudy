%%Loading Results and reference
type=1;
load(['Results/Ex' num2str(type) '.mat']);
load(['Data/Ex' num2str(type) '_Data.mat'],'x0','LocData');
LocData=ConstantData{2};
   
%% Kolmogorov-Smirnov test

deltax=2;deltay=2;
ind=(x0(:,1)<22 & x0(:,2)<22);
Noind=x0(:,1)>=(11-deltax) & x0(:,1)<=(11+deltax);
Pos=1:nx*ny;Pos=Pos(logical(ind-Noind));

a=0;Yall=[];jj=0; meanYeal=[];
while a<2000
    YDist=LUsim(x0,model,c,100000,[],[],14521+jj);
    YDista=[YDist; max(YDist(LocData{1},:)); max(YDist(LocData{2},:)); max(YDist(LocData{3},:)); max(YDist(LocData{4},:))];
    t1=YDista(nx*ny+1,:)<(ConstantData{1}(1)+0.1) & YDista(nx*ny+1,:)>(ConstantData{1}(1)-0.1);
    t2=YDista(nx*ny+2,:)<(ConstantData{1}(2)+0.1) & YDista(nx*ny+2,:)>(ConstantData{1}(2)-0.1);
    t3=YDista(nx*ny+3,:)<(ConstantData{1}(3)+0.1) & YDista(nx*ny+3,:)>(ConstantData{1}(3)-0.1);
    t4=YDista(nx*ny+4,:)<(ConstantData{1}(4)+0.1) & YDista(nx*ny+4,:)>(ConstantData{1}(4)-0.1);
    a=a+sum(t1&t2&t3&t4)
    Yall=[Yall,YDista(:,t1&t2&t3&t4)];
    meanYeal=[meanYeal , mean(YDist(:,t1&t2&t3&t4))];
    jj=jj+1;
end
%%
for j=1:nx*ny
    YDist=Yall(j,:);
    for i=1:6
        if i==1
            [h(j,i),p(j,i),d(j,i)]=kstest2(ZSimSSTBM(j,:),YDist);
        elseif i==2
            [h(j,i),p(j,i),d(j,i)]=kstest2(ZSimGD(j,:),YDist);
        elseif i==3
            [h(j,i),p(j,i),d(j,i)]=kstest2(ZSimISR(j,:),YDist);
        elseif i==4
            [h(j,i),p(j,i),d(j,i)]=kstest2(ZSimPA(j,:),YDist);
        elseif i==5
            [h(j,i),p(j,i),d(j,i)]=kstest2(ZSimFFTMASA(j,:),YDist);
        elseif i==6
            [h(j,i),p(j,i),d(j,i)]=kstest2(ZSimUC(j,:),YDist);
        end      
    end
end
sum(h)/(nx*ny)
figure(2)
boxplot(p,'Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC'},'Whisker',1)
hold on
plot([0 8],[0.05 0.05],'--k','markersize',8,'LineWidth',2)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
ylabel('p-value')
figure(52)
boxplot(d,'Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC'},'Whisker',1)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
ylabel('Kolmogorov-Smirnov test statistic')
%% A figure example

figure(1)
LocMid=[53 158 263 368];
imagesc(reshape(ZSimSSTBM(:,1),[nx ny])')
set(gca,'YDir','normal');
hold on
plot(x0([9 13 97 93 9],1)+[-0.5 0.5 0.5 -0.5 -0.5]',x0([9 13 97 93 9],2)+[-0.5 -0.5 0.5 0.5 -0.5]','-k','markersize',8,'LineWidth',2)
hold on
plot(x0([114 118 202 198 114],1)+[-0.5 0.5 0.5 -0.5 -0.5]',x0([114 118 202 198 114],2)+[-0.5 -0.5 0.5 0.5 -0.5]','-k','markersize',8,'LineWidth',2)
hold on
plot(x0([219 223 307 303 219],1)+[-0.5 0.5 0.5 -0.5 -0.5]',x0([219 223 307 303 219],2)+[-0.5 -0.5 0.5 0.5 -0.5]','-k','markersize',8,'LineWidth',2)
hold on
plot(x0([324 328 412 408 324],1)+[-0.5 0.5 0.5 -0.5 -0.5]',x0([324 328 412 408 324],2)+[-0.5 -0.5 0.5 0.5 -0.5]','-k','markersize',8,'LineWidth',2)
hold on
plot([11 11],[0.5 21],'--k','markersize',8,'LineWidth',1.5)
hold on
plot(x0(LocMid,1),x0(LocMid,2),'xk','markersize',16,'LineWidth',2)
colormap('jet');
xlim([0.5,nx+0.5]);
ylim([0.5,ny+0.5]);
colorbar();
caxis([-3 3]);
xlabel('Coord. x','FontSize',14);
ylabel('Coord. y','FontSize',14);
%% Figure Objective function evolution and quantiles
CI95
OFinit=(sum(errSSTBM(1,:))+sum(errGD(1,:))+sum(errISR(1,:))+sum(errPA(1,:))+sum(errFFTMASA(1,:)))/nbsim/5;
figure(7) 
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],mean(errSSTBM,2,'omitnan')/OFinit,'k','Linewidth',2);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],mean(errGD,2,'omitnan')/OFinit,'b','Linewidth',2);
hold on
p3=plot(mean(errISR,2,'omitnan')/OFinit,'r','Linewidth',2);
hold on
p4=plot(mean(errPA,2,'omitnan')/OFinit,'g','Linewidth',2);
hold on
p5=plot(mean(errFFTMASA,2,'omitnan')/OFinit,'m','Linewidth',2);
xlim([0 nbiter])
ylim([10^-4 1])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')

figure(8)
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],CISSTBM(:,1)/OFinit,'--k','Linewidth',1);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],CIGD(:,1)/OFinit,'--b','Linewidth',1);
hold on
p3=plot(CIISR(:,1)/OFinit,'--r','Linewidth',1);
hold on
p4=plot(CIPA(:,1)/OFinit,'--g','Linewidth',1);
hold on
p5=plot(CIFFTMASA(:,1)/OFinit,'--m','Linewidth',1);
hold on
plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],CISSTBM(:,2)/OFinit,'--k','Linewidth',1)
hold on
plot([MaxIterGD/2:MaxIterGD:nbiter],CIGD(:,2)/OFinit,'--b','Linewidth',1)
hold on
plot(CIISR(:,2)/OFinit,'--r','Linewidth',1)
hold on
plot(CIPA(:,2)/OFinit,'--g','Linewidth',1)
hold on
plot(CIFFTMASA(:,2)/OFinit,'--m','Linewidth',1)
xlim([0 nbiter])
ylim([10^-5 1])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')

%% absolut mean perturbation

figure(9) 
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],mean(deltaSSTBM,2,'omitnan'),'k','Linewidth',2);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],mean(deltaGD,2,'omitnan'),'b','Linewidth',2);
hold on
p3=plot(mean(deltaISR,2,'omitnan'),'r','Linewidth',2);
hold on
p4=plot(mean(deltaPA,2,'omitnan'),'g','Linewidth',2);
hold on
p5=plot(mean(deltaFFTMASA,2,'omitnan'),'m','Linewidth',2);
xlim([0 nbiter])
ylim([10^-2.5 1])
xlabel('number of OF evaluation i')
ylabel('Mean absolute perturbation')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')
%%
[mean(std(ZSimSSTBM')) mean(std(ZSimGD')) mean(std(ZSimISR')) mean(std(ZSimPA')) mean(std(ZSimFFTMASA'))]
[mean(corr(ZSimSSTBM),'all') mean(corr(ZSimGD),'all') mean(corr(ZSimISR),'all') mean(corr(ZSimPA),'all') mean(corr(ZSimFFTMASA),'all')]

