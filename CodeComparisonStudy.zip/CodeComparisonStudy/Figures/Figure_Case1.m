%%Loading Results and reference
type=1;
load(['Results/Ex' num2str(type) '.mat']);
load(['Data/Ex' num2str(type) '_Data.mat'],'x0','LocData');
LocData=ConstantData{2};
%% Sampling a reference figure
YDist=LUsim(x0([LocData{1}],:),model,c,2000000,[],[],14521);
YDista=[max(YDist)];

t1=YDista<(ConstantData{1}(1)+0.1) & YDista>(ConstantData{1}(1)-0.1);
t2=YDista<(ConstantData{1}(2)+0.1) & YDista>(ConstantData{1}(2)-0.1);
t3=YDista<(ConstantData{1}(3)+0.1) & YDista>(ConstantData{1}(3)-0.1);
t4=YDista<(ConstantData{1}(4)+0.1) & YDista>(ConstantData{1}(4)-0.1);

Y1=YDist(:,t1);Y1=Y1(:,1);
Y2=YDist(:,t2);Y2=Y2(:,1);
Y3=YDist(:,t3);Y3=Y3(:,1);
Y4=YDist(:,t4);Y4=Y4(:,1);

LocMid=[218,668,233,683];
Y=LUsim(x0,model,c,1,[Y1; Y2; Y3; Y4],[LocData{1},LocData{2},LocData{3},LocData{4}]',14521);

figure(1)
imagesc(reshape(Y,[nx ny]))
set(gca,'YDir','normal');
hold on
plot(x0(LocMid,1),x0(LocMid,2),'xk','markersize',8,'LineWidth',2)
hold on
plot(x0([621 625 745 741 621],1)+[-0.5 0.5 0.5 -0.5 -0.5]',x0([621 625 745 741 621],2)+[-0.5 -0.5 0.5 0.5 -0.5]','-k','markersize',8,'LineWidth',2)
hold on
plot(x0([171 175 295 291 171],1)+[-0.5 0.5 0.5 -0.5 -0.5]',x0([171 175 295 291 171],2)+[-0.5 -0.5 0.5 0.5 -0.5]','-k','markersize',8,'LineWidth',2)
hold on
plot(x0([606 610 730 726 606],1)+[-0.5 0.5 0.5 -0.5 -0.5]',x0([606 610 730 726 606],2)+[-0.5 -0.5 0.5 0.5 -0.5]','-k','markersize',8,'LineWidth',2)
hold on
plot(x0([156 160 280 276 156],1)+[-0.5 0.5 0.5 -0.5 -0.5]',x0([156 160 280 276 156],2)+[-0.5 -0.5 0.5 0.5 -0.5]','-k','markersize',8,'LineWidth',2)
hold on
plot([15.5 15.5],[0.5 30.5],'-k','markersize',8,'LineWidth',2)
hold on
plot([0.5 30.5],[15.5 15.5],'-k','markersize',8,'LineWidth',2)
hold on
plot([10.5 15.5],[23 23],'--k','markersize',8,'LineWidth',2)
hold on
plot([5],[21],'ok','markersize',8,'LineWidth',2)
hold on
plot([8],[23],'ok','markersize',8,'LineWidth',2)
colormap('jet');
xlim([0.5,nx+0.5]);
ylim([0.5,ny+0.5]);
colorbar();
caxis([-3 3]);
%% Procedure example
nodes=605;
YDist=LUsim(x0([nodes,LocData{2}],:),model,c,2000000,[],[],121);
YDist=[YDist(1,:); max(YDist(2:end,:))];

figure(25)
plot(YDist(1,1:500000),YDist(2,1:500000),'*b');
hold on
plot(ZSimSSTBM(nodes,:),-0.5*ones(nbsim,1),'*r');
hold on
plot([-4 4],[-4 4],'-k','markersize',8,'LineWidth',2);
xlim([-4 4])
ylim([-2 5])
ylabel('Maximum distribution')
xlabel('Point distribution')
legend('Simulation','Calibration','Equal line')

figure(26)
YDist=YDist(:,YDist(2,:)<(ConstantData{1}(2)+0.01) & YDist(2,:)>(ConstantData{1}(2)-0.01));
[Fref,xref]=ecdf(YDist(1,:));
[Fsim,xsim]=ecdf(ZSimFFTMASA(nodes,:));
plot(xref,Fref,'b','markersize',8,'LineWidth',2)
hold on
plot(xsim,Fsim,'r','markersize',8,'LineWidth',2)
xlim([-3.5 1.5])
ylabel('Empirical cumulative distribution')
xlabel('Node values')
legend('Simulation','Calibration','Localisation','best')
kstest2(YDist(1,:),ZSimISR(nodes,:))
%% Kolmogorov-Smirnov test performs on each cadran (200 points test in each)
% Cadran 1
deltax=2;deltay=2;
ind=(x0(:,1)<16 & x0(:,2)<16);
Noind=x0(:,1)>=(8-deltax) & x0(:,1)<=(8+deltax) & x0(:,2)>=(8-deltay) & x0(:,2)<=(8+deltay);
Pos=1:nx*ny;Pos=Pos(logical(ind-Noind));
for j=1:length(Pos)
    YDist=LUsim(x0([Pos(j),LocData{1}],:),model,c,20000000,[],[],14521+j);
    YDist=[YDist(1,:); max(YDist(2:25+1,:))];   
    YDist=YDist(:,YDist(2,:)<(ConstantData{1}(1)+0.01) & YDist(2,:)>(ConstantData{1}(1)-0.01));
    a1(j)=size(YDist,2);
    for i=1:6
        if i==1
            [h1(j,i),p1(j,i)]=kstest2(ZSimSSTBM(Pos(j),:),YDist(1,:));
        elseif i==2
            [h1(j,i),p1(j,i)]=kstest2(ZSimGD(Pos(j),:),YDist(1,:));
        elseif i==3
            [h1(j,i),p1(j,i)]=kstest2(ZSimISR(Pos(j),:),YDist(1,:));
        elseif i==4
            [h1(j,i),p1(j,i)]=kstest2(ZSimPA(Pos(j),:),YDist(1,:));
        elseif i==5
            [h1(j,i),p1(j,i)]=kstest2(ZSimFFTMASA(Pos(j),:),YDist(1,:));
        elseif i==6
            [h1(j,i),p1(j,i)]=kstest2(ZSimUC(Pos(j),:),YDist(1,:));
        end      
    end
end
sum(h1)/200
figure(2)
boxplot(p1,'Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC'},'Whisker',1)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
% Cadran 2
deltax=2;deltay=2;
ind=(x0(:,1)<16 & x0(:,2)>=16);
Noind=x0(:,1)>=(8-deltax) & x0(:,1)<=(8+deltax) & x0(:,2)>=(23-deltay) & x0(:,2)<=(23+deltay);
Pos=1:nx*ny;Pos=Pos(logical(ind-Noind));
for j=1:length(Pos)
    YDist=LUsim(x0([Pos(j),LocData{2}],:),model,c,2000000,[],[],14521+j);
    YDist=[YDist(1,:); max(YDist(2:25+1,:))];   
    YDist=YDist(:,YDist(2,:)<(ConstantData{1}(2)+0.01) & YDist(2,:)>(ConstantData{1}(2)-0.01));
    a2(j)=size(YDist,2);
    for i=1:6
        if i==1
            [h2(j,i),p2(j,i)]=kstest2(ZSimSSTBM(Pos(j),:),YDist(1,:));
        elseif i==2
            [h2(j,i),p2(j,i)]=kstest2(ZSimGD(Pos(j),:),YDist(1,:));
        elseif i==3
            [h2(j,i),p2(j,i)]=kstest2(ZSimISR(Pos(j),:),YDist(1,:));
        elseif i==4
            [h2(j,i),p2(j,i)]=kstest2(ZSimPA(Pos(j),:),YDist(1,:));
        elseif i==5
            [h2(j,i),p2(j,i)]=kstest2(ZSimFFTMASA(Pos(j),:),YDist(1,:));
        elseif i==6
            [h2(j,i),p2(j,i)]=kstest2(ZSimUC(Pos(j),:),YDist(1,:));
        end      
    end
end
sum(h2)/200
figure(3)
boxplot(p2,'Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC'},'Whisker',1)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
% Cadran 3
deltax=2;deltay=2;
ind=(x0(:,1)>=16 & x0(:,2)<16);
Noind=x0(:,1)>=(23-deltax) & x0(:,1)<=(23+deltax) & x0(:,2)>=(8-deltay) & x0(:,2)<=(8+deltay);
Pos=1:nx*ny;Pos=Pos(logical(ind-Noind));
for j=1:length(Pos)
    YDist=LUsim(x0([Pos(j),LocData{3}],:),model,c,3000000,[],[],14521+j);
    YDist=[YDist(1,:); max(YDist(2:25+1,:))];   
    YDist=YDist(:,YDist(2,:)<(ConstantData{1}(3)+0.01) & YDist(2,:)>(ConstantData{1}(3)-0.01));
    a3(j)=size(YDist,2);
    for i=1:6
        if i==1
            [h3(j,i),p3(j,i)]=kstest2(ZSimSSTBM(Pos(j),:),YDist(1,:));
        elseif i==2
            [h3(j,i),p3(j,i)]=kstest2(ZSimGD(Pos(j),:),YDist(1,:));
        elseif i==3
            [h3(j,i),p3(j,i)]=kstest2(ZSimISR(Pos(j),:),YDist(1,:));
        elseif i==4
            [h3(j,i),p3(j,i)]=kstest2(ZSimPA(Pos(j),:),YDist(1,:));
        elseif i==5
            [h3(j,i),p3(j,i)]=kstest2(ZSimFFTMASA(Pos(j),:),YDist(1,:));
        elseif i==6
            [h3(j,i),p3(j,i)]=kstest2(ZSimUC(Pos(j),:),YDist(1,:));
        end      
    end
end
sum(h3)/200
figure(4)
boxplot(p3,'Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC'},'Whisker',1)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
% Cadran 4
deltax=2;deltay=2;
ind=(x0(:,1)>=16 & x0(:,2)>=16);
Noind=x0(:,1)>=(23-deltax) & x0(:,1)<=(23+deltax) & x0(:,2)>=(23-deltay) & x0(:,2)<=(23+deltay);
Pos=1:nx*ny;Pos=Pos(logical(ind-Noind));
for j=1:length(Pos)
    YDist=LUsim(x0([Pos(j),LocData{4}],:),model,c,2000000,[],[],14521+j);
    YDist=[YDist(1,:); max(YDist(2:25+1,:))];   
    YDist=YDist(:,YDist(2,:)<(ConstantData{1}(4)+0.01) & YDist(2,:)>(ConstantData{1}(4)-0.01));
    a4(j)=size(YDist,2);
    for i=1:6
        if i==1
            [h4(j,i),p4(j,i)]=kstest2(ZSimSSTBM(Pos(j),:),YDist(1,:));
        elseif i==2
            [h4(j,i),p4(j,i)]=kstest2(ZSimGD(Pos(j),:),YDist(1,:));
        elseif i==3
            [h4(j,i),p4(j,i)]=kstest2(ZSimISR(Pos(j),:),YDist(1,:));
        elseif i==4
            [h4(j,i),p4(j,i)]=kstest2(ZSimPA(Pos(j),:),YDist(1,:));
        elseif i==5
            [h4(j,i),p4(j,i)]=kstest2(ZSimFFTMASA(Pos(j),:),YDist(1,:));
        elseif i==6
            [h4(j,i),p4(j,i)]=kstest2(ZSimUC(Pos(j),:),YDist(1,:));
        end      
    end
end
sum(h4)/200
figure(5)
boxplot(p4,'Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC'},'Whisker',1)
set(gca,'FontSize',10,'XTickLabelRotation',-25)

% All Merged
hall=double([h1; h2; h3; h4]);
pall=double([p1; p2; p3; p4]);
sum(hall)/800
figure(6)
boxplot(pall,'Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC'},'Whisker',1)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
%% Figure Objective function evolution and quantiles
CI95
OFinit=(sum(errSSTBM(1,:))+sum(errGD(1,:))+sum(errISR(1,:))+sum(errPA(1,:))+sum(errFFTMASA(1,:)))/nbsim/5;
figure(7) 
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],mean(errSSTBM,2,'omitnan')/OFinit,'k','Linewidth',2);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],mean(errGD,2,'omitnan')/OFinit,'b','Linewidth',2);
hold on
p3=plot(mean(errISR,2,'omitnan')/OFinit,'r','Linewidth',2);
hold on
p4=plot(mean(errPA,2,'omitnan')/OFinit,'g','Linewidth',2);
hold on
p5=plot(mean(errFFTMASA,2,'omitnan')/OFinit,'m','Linewidth',2);
xlim([0 nbiter])
ylim([10^-5.8 1])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')

figure(8)
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],CISSTBM(:,1)/OFinit,'--k','Linewidth',1);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],CIGD(:,1)/OFinit,'--b','Linewidth',1);
hold on
p3=plot(CIISR(:,1)/OFinit,'--r','Linewidth',1);
hold on
p4=plot(CIPA(:,1)/OFinit,'--g','Linewidth',1);
hold on
p5=plot(CIFFTMASA(:,1)/OFinit,'--m','Linewidth',1);
hold on
plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],CISSTBM(:,2)/OFinit,'--k','Linewidth',1)
hold on
plot([MaxIterGD/2:MaxIterGD:nbiter],CIGD(:,2)/OFinit,'--b','Linewidth',1)
hold on
plot(CIISR(:,2)/OFinit,'--r','Linewidth',1)
hold on
plot(CIPA(:,2)/OFinit,'--g','Linewidth',1)
hold on
plot(CIFFTMASA(:,2)/OFinit,'--m','Linewidth',1)
xlim([0 nbiter])
ylim([10^-6 1])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')

%% absolut mean perturbation

figure(9) 
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],mean(deltaSSTBM,2,'omitnan'),'k','Linewidth',2);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],mean(deltaGD,2,'omitnan'),'b','Linewidth',2);
hold on
p3=plot(mean(deltaISR,2,'omitnan'),'r','Linewidth',2);
hold on
p4=plot(mean(deltaPA,2,'omitnan'),'g','Linewidth',2);
hold on
p5=plot(mean(deltaFFTMASA,2,'omitnan'),'m','Linewidth',2);
xlim([0 nbiter])
ylim([10^-3.5 1])
xlabel('number of OF evaluation i')
ylabel('Mean absolute perturbation')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')
%%
figure(11); imagesc(reshape(std(ZSimSSTBM'),[nx ny])); colormap('jet'); colorbar();caxis([0.5 1]);set(gca,'YDir','normal');
figure(12); imagesc(reshape(std(ZSimGD'),[nx ny])); colormap('jet'); colorbar();caxis([0.5 1]);set(gca,'YDir','normal');
figure(13); imagesc(reshape(std(ZSimISR'),[nx ny])); colormap('jet'); colorbar();caxis([0.5 1]);set(gca,'YDir','normal');
figure(14); imagesc(reshape(std(ZSimPA'),[nx ny])); colormap('jet'); colorbar();caxis([0.5 1]);set(gca,'YDir','normal');
figure(15); imagesc(reshape(std(ZSimFFTMASA'),[nx ny])); colormap('jet'); colorbar();caxis([0.5 1]);set(gca,'YDir','normal');

[mean(std(ZSimSSTBM')) mean(std(ZSimGD')) mean(std(ZSimISR')) mean(std(ZSimPA')) mean(std(ZSimFFTMASA'))]
[mean(corr(ZSimSSTBM),'all') mean(corr(ZSimGD),'all') mean(corr(ZSimISR),'all') mean(corr(ZSimPA),'all') mean(corr(ZSimFFTMASA),'all')]

%%
