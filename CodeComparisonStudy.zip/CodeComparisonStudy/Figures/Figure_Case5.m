%%Loading Results and reference
type=5;
load(['Results/Ex' num2str(type) '.mat']);
load(['Data/Ex' num2str(type) '_Data.mat'],'zrefGaus');
%% Figure reference, uncalibrated, calibrated

U_ref=reshape(((tiedrank(reshape(zrefGaus,[],1)) - 0.5) / (nx*ny)),[nx ny]);
U_UC=reshape(((tiedrank(reshape(ZSimUC(:,2),[],1)) - 0.5) / (nx*ny)),[nx ny]);
U_C=reshape(((tiedrank(reshape(ZSimSSTBM(:,2),[],1)) - 0.5) / (nx*ny)),[nx ny]);

figure(1)
imagesc(U_ref);set(gca,'YDir','normal');colormap('jet');xlim([1,100]);ylim([1,100]);colorbar();caxis([0 1]);
xlabel('Coord. x','FontSize',14);
ylabel('Coord. y','FontSize',14);
figure(2)
imagesc(U_UC);set(gca,'YDir','normal');colormap('jet');xlim([1,100]);ylim([1,100]);colorbar();caxis([0 1]);
xlabel('Coord. x','FontSize',14);
ylabel('Coord. y','FontSize',14);
figure(3)
imagesc(U_C);set(gca,'YDir','normal');colormap('jet');xlim([1,100]);ylim([1,100]);colorbar();caxis([0 1]);
xlabel('Coord. x','FontSize',14);
ylabel('Coord. y','FontSize',14);
%% Figure Directional Assymetry

VarSimC=varioFFT2D_dl( x0 , ZSimSSTBM(:,1:nbsim) , [8 3] , 0 , 0 );
VarSimPA=varioFFT2D_dl( x0 , ZSimPA(:,1:nbsim) , [8 3] , 0 , 0 );
VarSimGD=varioFFT2D_dl( x0 , ZSimGD(:,1:nbsim) , [8 3] , 0 , 0 );
VarSimISR=varioFFT2D_dl( x0 , ZSimISR(:,1:nbsim) , [8 3] , 0 , 0 );
VarSimfftmaSA=varioFFT2D_dl( x0 , ZSimFFTMASA(:,1:nbsim) , [8 3] , 0 , 0 );
VarSimUC=varioFFT2D_dl( x0 , ZSimUC(:,1:nbsim) , [8 3] , 0 , 0 );


VarRefx=varioFFT2D_dl( x0 , zrefGaus , [8 3] , 0 , 0 );

figure(4)

meanvarSimC=zeros(length(VarSimC{1,1}(:,ny)),1);
meanvarSimGD=zeros(length(VarSimGD{1,1}(:,ny)),1);
meanvarSimPA=zeros(length(VarSimPA{1,1}(:,ny)),1);
meanvarSimISR=zeros(length(VarSimISR{1,1}(:,ny)),1);
meanvarSimfftmaSA=zeros(length(VarSimfftmaSA{1,1}(:,ny)),1);
for i=1:nbsim
    meanvarSimC=meanvarSimC+VarSimC{i,i}(:,ny)/nbsim;
    meanvarSimPA=meanvarSimPA+VarSimPA{i,i}(:,ny)/nbsim;
    meanvarSimGD=meanvarSimGD+VarSimGD{i,i}(:,ny)/nbsim;
    meanvarSimISR=meanvarSimISR+VarSimISR{i,i}(:,ny)/nbsim;
    meanvarSimfftmaSA=meanvarSimfftmaSA+VarSimfftmaSA{i,i}(:,ny)/nbsim;
end
for i=1:nbsim
    plot(-99:1:99,VarSimUC{i,i}(:,ny)','LineWidth',1,'color',[0.9 0.9 0.9]);
    hold on
end
h1=plot(-99:1:99,meanvarSimC,'-k','LineWidth',1);
hold on
h2=plot(-99:1:99,meanvarSimGD,'-b','LineWidth',1);
hold on
h3=plot(-99:1:99,meanvarSimPA,'-g','LineWidth',1);
hold on
h4=plot(-99:1:99,meanvarSimISR,'-r','LineWidth',1);
hold on
h5=plot(-99:1:99,meanvarSimfftmaSA,'-m','LineWidth',1);
hold on
plot(-95:5:99,VarRefx{1}(5:5:end,ny),'*k')
hold on
legend([h1 h2 h3 h4 h5],'S-STBM','GD','PA','ISR','FFTMA-SA','location','southeast')
xlabel('Lag distance')
ylabel('Directional asymmetry (N-S)')
xlim([-25 25])
ylim([-0.05 0.05])

figure(5)

meanvarSimC=zeros(length(VarSimC{1,1}(nx,:)),1);
meanvarSimGD=zeros(length(VarSimGD{1,1}(nx,:)),1);
meanvarSimPA=zeros(length(VarSimPA{1,1}(nx,:)),1);
meanvarSimISR=zeros(length(VarSimISR{1,1}(nx,:)),1);
meanvarSimfftmaSA=zeros(length(VarSimfftmaSA{1,1}(nx,:)),1);
for i=1:nbsim
    meanvarSimC=meanvarSimC+VarSimC{i,i}(nx,:)'/nbsim;
    meanvarSimPA=meanvarSimPA+VarSimPA{i,i}(nx,:)'/nbsim;
    meanvarSimGD=meanvarSimGD+VarSimGD{i,i}(nx,:)'/nbsim;
    meanvarSimISR=meanvarSimISR+VarSimISR{i,i}(nx,:)'/nbsim;
    meanvarSimfftmaSA=meanvarSimfftmaSA+VarSimfftmaSA{i,i}(nx,:)'/nbsim;
end
for i=1:nbsim
    plot(-99:1:99,VarSimUC{i,i}(nx,:)','LineWidth',1,'color',[0.9 0.9 0.9]);
    hold on
end
h1=plot(-99:1:99,meanvarSimC,'-k','LineWidth',1);
hold on
h2=plot(-99:1:99,meanvarSimGD,'-b','LineWidth',1);
hold on
h3=plot(-99:1:99,meanvarSimPA,'-g','LineWidth',1);
hold on
h4=plot(-99:1:99,meanvarSimISR,'-r','LineWidth',1);
hold on
h5=plot(-99:1:99,meanvarSimfftmaSA,'-m','LineWidth',1);
hold on
plot(-95:5:99,VarRefx{1}(nx,5:5:end),'*k')
legend([h1 h2 h3 h4 h5],'S-STBM','GD','PA','ISR','FFTMA-SA','Location','southeast')
xlabel('Lag distance')
ylabel('Directional asymmetry (W-E)')
xlim([-25 25])
ylim([-0.05 0.05])




%% Figure Objective function evolution and quantiles
CI95
OFinit=(sum(errSSTBM(1,:))+sum(errGD(1,:))+sum(errISR(1,:))+sum(errPA(1,:))+sum(errFFTMASA(1,:)))/nbsim/5;
figure(6) 
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],mean(errSSTBM,2,'omitnan')/OFinit,'k','Linewidth',2);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],mean(errGD,2,'omitnan')/OFinit,'b','Linewidth',2);
hold on
p3=plot(mean(errISR,2,'omitnan')/OFinit,'r','Linewidth',2);
hold on
p4=plot(mean(errPA,2,'omitnan')/OFinit,'g','Linewidth',2);
hold on
p5=plot(mean(errFFTMASA,2,'omitnan')/OFinit,'m','Linewidth',2);
xlim([0 nbiter])
ylim([10^-2 1])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')

figure(7)
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],CISSTBM(:,1)/OFinit,'--k','Linewidth',1);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],CIGD(:,1)/OFinit,'--b','Linewidth',1);
hold on
p3=plot(CIISR(:,1)/OFinit,'--r','Linewidth',1);
hold on
p4=plot(CIPA(:,1)/OFinit,'--g','Linewidth',1);
hold on
p5=plot(CIFFTMASA(:,1)/OFinit,'--m','Linewidth',1);
hold on
plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],CISSTBM(:,2)/OFinit,'--k','Linewidth',1)
hold on
plot([MaxIterGD/2:MaxIterGD:nbiter],CIGD(:,2)/OFinit,'--b','Linewidth',1)
hold on
plot(CIISR(:,2)/OFinit,'--r','Linewidth',1)
hold on
plot(CIPA(:,2)/OFinit,'--g','Linewidth',1)
hold on
plot(CIFFTMASA(:,2)/OFinit,'--m','Linewidth',1)
xlim([0 nbiter])
ylim([10^-2 1])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')
%% absolut mean perturbation

figure(8) 
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],mean(deltaSSTBM,2,'omitnan'),'k','Linewidth',2);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],mean(deltaGD,2,'omitnan'),'b','Linewidth',2);
hold on
p3=plot(mean(deltaISR,2,'omitnan'),'r','Linewidth',2);
hold on
p4=plot(mean(deltaPA,2,'omitnan'),'g','Linewidth',2);
hold on
p5=plot(mean(deltaFFTMASA,2,'omitnan'),'m','Linewidth',2);
xlim([0 nbiter])
ylim([10^-3.5 1])
xlabel('number of OF evaluation i')
ylabel('Mean absolute perturbation')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')
%%
[mean(std(ZSimSSTBM')) mean(std(ZSimGD')) mean(std(ZSimISR')) mean(std(ZSimPA')) mean(std(ZSimFFTMASA'))]