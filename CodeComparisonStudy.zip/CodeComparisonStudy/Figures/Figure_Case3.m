%%Loading Results and reference
type=3;
load(['Results/Ex' num2str(type) '.mat']);
load(['Data/Ex' num2str(type) '_Data.mat'],'zrefGaus','LocData','LocInj','x0','hField');
%% Figure reference
figure(1)
x = linspace(1,nx,ny);
y = linspace(1,nx,ny);
[X,Y] = meshgrid(x,y);
Z = reshape(hField,[nx,ny])';
imagesc(reshape(hField,[nx,ny])');
hold on 
plot(x0(LocInj,1),x0(LocInj,2),'ok','markersize',8,'LineWidth',2)
hold on 
plot(x0(LocData,1),x0(LocData,2),'xk','markersize',8,'LineWidth',2)
hold on
[c1,h]=contour(X,Y,Z,[0.80,0.80,0.40,0.40,0.0 0.0,-0.40 -0.40],'--k','ShowText','on');
h.LevelList=round(h.LevelList,2); 
clabel(c1,h)
colormap(jet)
colorbar()
caxis([-1 1])
set(gca,'YDir','normal')
title('Reference heads (m)')
xlabel('Coord. x','FontSize',14);
ylabel('Coord. y','FontSize',14);

figure(2)
imagesc(reshape(zrefGaus-3,[nx,ny])');
hold on 
plot(x0(LocInj,1),x0(LocInj,2),'ok','markersize',8,'LineWidth',2)
hold on 
plot(x0(LocData,1),x0(LocData,2),'xk','markersize',8,'LineWidth',2)
clabel(c1,h)
colormap(jet)
colorbar()
title('Reference log_1_0K (m/s)')
set(gca,'YDir','normal')
xlabel('Coord. x','FontSize',14);
ylabel('Coord. y','FontSize',14);
%% Figure Objective function evolution and quantiles
CI95
OFinit=(sum(errSSTBM(1,:))+sum(errGD(1,:))+sum(errISR(1,:))+sum(errPA(1,:))+sum(errFFTMASA(1,:)))/nbsim/5;
figure(3) 
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],mean(errSSTBM,2,'omitnan')/OFinit,'k','Linewidth',2);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],mean(errGD,2,'omitnan')/OFinit,'b','Linewidth',2);
hold on
p3=plot(mean(errISR,2,'omitnan')/OFinit,'r','Linewidth',2);
hold on
p4=plot(mean(errPA,2,'omitnan')/OFinit,'g','Linewidth',2);
hold on
p5=plot(mean(errFFTMASA,2,'omitnan')/OFinit,'m','Linewidth',2);
xlim([0 nbiter])
ylim([10^-4.5 1])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')

figure(4)
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],CISSTBM(:,1)/OFinit,'--k','Linewidth',1);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],CIGD(:,1)/OFinit,'--b','Linewidth',1);
hold on
p3=plot(CIISR(:,1)/OFinit,'--r','Linewidth',1);
hold on
p4=plot(CIPA(:,1)/OFinit,'--g','Linewidth',1);
hold on
p5=plot(CIFFTMASA(:,1)/OFinit,'--m','Linewidth',1);
hold on
plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],CISSTBM(:,2)/OFinit,'--k','Linewidth',1)
hold on
plot([MaxIterGD/2:MaxIterGD:nbiter],CIGD(:,2)/OFinit,'--b','Linewidth',1)
hold on
plot(CIISR(:,2)/OFinit,'--r','Linewidth',1)
hold on
plot(CIPA(:,2)/OFinit,'--g','Linewidth',1)
hold on
plot(CIFFTMASA(:,2)/OFinit,'--m','Linewidth',1)
xlim([0 nbiter])
ylim([10^-5 1])
xlabel('number of OF evaluation i')
ylabel('Normalized objective function')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')
%% Boxplot misfit 

ZSimALL=[zrefGaus ZSimSSTBM ZSimGD  ZSimISR  ZSimPA ZSimFFTMASA ZSimUC];
clear h
for i=1:size(ZSimALL,2)
    h(:,i)=SIMcdmscale(ZSimALL(:,i),type);
end

dist=nan(size(ZSimALL,2),size(ZSimALL,2));
for ii=1:size(ZSimALL,2)
    for jj=ii:size(ZSimALL,2)
        dist(ii,jj)=sqrt(mean((h(:,ii)-h(:,jj)).^2));
        dist(jj,ii)=dist(ii,jj);
    end
end

figure(5)
boxplot([dist(1,0*nbsim+2:1*nbsim+1)',dist(1,1*nbsim+2:2*nbsim+1)',dist(1,2*nbsim+2:3*nbsim+1)',dist(1,3*nbsim+2:4*nbsim+1)',dist(1,4*nbsim+2:5*nbsim+1)',dist(1,5*nbsim+2:6*nbsim+1)'],'Labels',{'S-STBM','GD','ISR','PA','FFTMA-SA','UC'},'Whisker',1)
set(gca,'FontSize',10,'XTickLabelRotation',-25)
ylim([0 0.8])
ylabel('Root-Mean-Squared Error')
%% absolut mean perturbation

figure(6) 
p1=plot([MaxIterSSTBM/2:MaxIterSSTBM:nbiter],mean(deltaSSTBM,2,'omitnan'),'k','Linewidth',2);
hold on
p2=plot([MaxIterGD/2:MaxIterGD:nbiter],mean(deltaGD,2,'omitnan'),'b','Linewidth',2);
hold on
p3=plot(mean(deltaISR,2,'omitnan'),'r','Linewidth',2);
hold on
p4=plot(mean(deltaPA,2,'omitnan'),'g','Linewidth',2);
hold on
p5=plot(mean(deltaFFTMASA,2,'omitnan'),'m','Linewidth',2);
xlim([0 nbiter])
ylim([10^-3.5 1])
xlabel('number of OF evaluation i')
ylabel('Mean absolute perturbation')
set(gca, 'YScale', 'log')
legend([p1 p2 p3 p4 p5],'S-STBM','GD','ISR','PA','FFTMA-SA')
%%
[mean(std(ZSimSSTBM')) mean(std(ZSimGD')) mean(std(ZSimISR')) mean(std(ZSimPA')) mean(std(ZSimFFTMASA'))]
[mean(corr(ZSimSSTBM),'all') mean(corr(ZSimGD),'all') mean(corr(ZSimISR),'all') mean(corr(ZSimPA),'all') mean(corr(ZSimFFTMASA),'all')]

