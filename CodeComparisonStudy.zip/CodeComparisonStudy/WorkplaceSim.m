addpath(genpath('Data'))
addpath(genpath('Function'))
addpath(genpath('Reference'))
addpath(genpath('Figures'))

%To run case 3 and 4, you need the Matlab Reservoir Simulation Toolbox
%(MRST) available at : https://www.sintef.no/projectweb/mrst/

%addpath(genpath('mrst-2020a'))

%type = 1 : case 1 Maximum test area
%type = 2 : case 2 Categories, Alternative to Gibbs sampler
%type = 3 : case 3 Pressure head
%type = 4 : case 4 First arrival travel time
%type = 5 : case 5 Directional asymmetry
type =5;
%%
clearvars -except type
%Run the reference
RunReference(type)
%%
%Load Simulations parameters
[model,c,nx,ny,nz,zHD,LocHD,nbiter,nbsim,OFmin,seed,ConstantData]=ParamSimulation(type);
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid
saveData='true'; %Save the data
%%
%For fast computation, the number of simulations is fixed to 6 and the number
%of iteration is fixed to 500. Parfor loop are removed in each algorithm
%(SSTBM,GD,ISR,PA,FFTMASA,STBM) but can be easily added.
nbsim=6; nbiter=500;

%Unconditional simulation obtained by spectral simulations (STBM) or either
%Choleski decomposition (LUsim)
nl=2000;
[ZSimUC]=STBM(x0,model,c,nbsim,zHD,LocHD,nl,seed);

%Calibrated realizations obtained by S-STBM
MaxIterSSTBM=2;nl=nbiter/MaxIterSSTBM;
[ZSimSSTBM,errSSTBM,deltaSSTBM]=S_STBM(x0,model,c,nbsim,zHD,LocHD,nl,MaxIterSSTBM,type,OFmin,seed,ConstantData);

%Calibrated realizations obtained by GD
MaxIterGD=10;nbOpt=nbiter/MaxIterGD;
[ZSimGD,errGD,deltaGD]=GD(x0,model,c,nbsim,zHD,LocHD,nbOpt,MaxIterGD,type,OFmin,seed,ConstantData);
%Calibrated realizations obtained by ISR
nbOpt=nbiter; phiMax=5/100;coef=0;
[ZSimISR,errISR,deltaISR]=ISR(x0,model,c,nbsim,zHD,LocHD,nbOpt,phiMax,coef,type,OFmin,seed,ConstantData);
%Calibrated realizations obtained by PA
nbOpt=nbiter;
Tstart=0.01;Tfac=1/1.05;Tstep=10;
Nstart=500;Nfac=1/1.05;Nstep=10;
[ZSimPA,errPA,deltaPA]=PA(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);
%Calibrated realizations obtained by FFTMA-SA
nbOpt=nbiter;
Tstart=0.01;Tfac=1/1.05;Tstep=10;
Nstart=ceil(0.8)*size(x0,1);Nfac=1/1.05;Nstep=10;
[ZSimFFTMASA,errFFTMASA,deltaFFTMASA]=FFTMASA(x0,model,c,nbsim,zHD,LocHD,nbOpt,Tstart,Tfac,Tstep,Nstart,Nfac,Nstep,type,OFmin,seed,ConstantData);

%Save results in a folder
if saveData=='true'
    save(['Results/Ex' num2str(type) '.mat']);
end
